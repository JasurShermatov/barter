#!/usr/bin/env bash
# Kodni yangilagandan keyin ishga tushirish:  sudo bash deploy/update.sh
set -euo pipefail
APP_DIR=/opt/barter_tizimi
cd "$APP_DIR"
sudo -u barter "$APP_DIR/.venv/bin/pip" install -q -r requirements.txt
sudo -u barter "$APP_DIR/.venv/bin/python" manage.py migrate --noinput
sudo -u barter "$APP_DIR/.venv/bin/python" manage.py collectstatic --noinput >/dev/null
systemctl restart barter-web barter-bot
systemctl --no-pager status barter-web | head -5
