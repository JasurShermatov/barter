#!/usr/bin/env bash
# Kunlik zaxira nusxa. Cron:  0 2 * * * /opt/barter_tizimi/deploy/backup.sh
set -euo pipefail
DIR=/var/backups/barter
mkdir -p "$DIR"
STAMP=$(date +%F)
sudo -u postgres pg_dump barter | gzip > "$DIR/barter_$STAMP.sql.gz"
find "$DIR" -name "barter_*.sql.gz" -mtime +30 -delete
echo "Zaxira: $DIR/barter_$STAMP.sql.gz"
