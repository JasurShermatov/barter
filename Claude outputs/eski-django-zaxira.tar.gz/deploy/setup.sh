#!/usr/bin/env bash
# Barter tizimini toza Ubuntu serverga birinchi marta o'rnatish.
# Ishlatish:  sudo bash deploy/setup.sh barter.example.uz
set -euo pipefail

DOMAIN="${1:-txtbarter.uz}"
APP_DIR=/opt/barter_tizimi
DB_NAME=barter
DB_USER=barter

echo "TXT BARTER BY EZZYJON — o'rnatish. Domen: $DOMAIN"
if [ "$(id -u)" != "0" ]; then
  echo "sudo bilan ishga tushiring."
  exit 1
fi

echo "==> 1/8 Paketlar o'rnatilmoqda"
apt-get update -qq
apt-get install -y -qq python3-venv python3-pip postgresql nginx git

echo "==> 2/8 Foydalanuvchi va papka"
id -u barter >/dev/null 2>&1 || useradd --system --create-home --shell /bin/bash barter
mkdir -p "$APP_DIR"
# Skript loyiha papkasidan ishga tushiriladi; fayllarni ko'chiramiz
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [ "$SRC" != "$APP_DIR" ]; then
  cp -r "$SRC/." "$APP_DIR/"
fi
chown -R barter:barter "$APP_DIR"

echo "==> 3/8 Ma'lumotlar bazasi"
DB_PASS="$(openssl rand -hex 16)"
sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'" | grep -q 1 \
  && sudo -u postgres psql -qc "ALTER ROLE $DB_USER WITH PASSWORD '$DB_PASS';" \
  || sudo -u postgres psql -qc "CREATE ROLE $DB_USER LOGIN PASSWORD '$DB_PASS';"
sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" | grep -q 1 \
  || sudo -u postgres createdb -O "$DB_USER" "$DB_NAME"

echo "==> 4/8 .env fayli"
if [ ! -f "$APP_DIR/.env" ]; then
  cat > "$APP_DIR/.env" <<ENV
SECRET_KEY=$(openssl rand -hex 32)
DEBUG=False
ALLOWED_HOSTS=$DOMAIN,www.$DOMAIN,localhost,127.0.0.1
CSRF_TRUSTED_ORIGINS=https://$DOMAIN,https://www.$DOMAIN,http://$DOMAIN
BEHIND_PROXY=True
SECURE_COOKIES=False
DB_ENGINE=postgres
POSTGRES_DB=$DB_NAME
POSTGRES_USER=$DB_USER
POSTGRES_PASSWORD=$DB_PASS
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
LOG_LEVEL=INFO
ENV
  chown barter:barter "$APP_DIR/.env"
  chmod 600 "$APP_DIR/.env"
  echo "    .env yaratildi (SSL o'rnatilgach SECURE_COOKIES=True qilib qo'yasiz)"
else
  echo "    .env allaqachon bor, o'zgartirilmadi"
fi

echo "==> 5/8 Python muhiti va migratsiyalar"
sudo -u barter python3 -m venv "$APP_DIR/.venv"
sudo -u barter "$APP_DIR/.venv/bin/pip" install -q --upgrade pip
sudo -u barter "$APP_DIR/.venv/bin/pip" install -q -r "$APP_DIR/requirements.txt"
cd "$APP_DIR"
sudo -u barter "$APP_DIR/.venv/bin/python" manage.py makemigrations accounts barter audit telegram_bot --noinput
sudo -u barter "$APP_DIR/.venv/bin/python" manage.py migrate --noinput
sudo -u barter "$APP_DIR/.venv/bin/python" manage.py collectstatic --noinput >/dev/null

echo "==> 6/8 systemd servislari"
cp "$APP_DIR/deploy/barter-web.service" /etc/systemd/system/
cp "$APP_DIR/deploy/barter-bot.service" /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now barter-web barter-bot

echo "==> 7/8 Nginx"
sed "s/DOMEN/$DOMAIN/g" "$APP_DIR/deploy/nginx.conf" > /etc/nginx/sites-available/barter
ln -sf /etc/nginx/sites-available/barter /etc/nginx/sites-enabled/barter
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

echo "==> 8/8 Admin foydalanuvchi"
echo "    Quyida login va parol so'raladi (bu bilan saytga kirasiz):"
cd "$APP_DIR" && sudo -u barter "$APP_DIR/.venv/bin/python" manage.py createsuperuser

cat <<DONE

================================================================
Tayyor.  Sayt:  http://$DOMAIN   (TXT BARTER BY EZZYJON)
Keyingi qadamlar:
  1) HTTPS:   sudo apt install -y certbot python3-certbot-nginx
              sudo certbot --nginx -d $DOMAIN -d www.$DOMAIN
              keyin .env ichida SECURE_COOKIES=True qilib:
              sudo systemctl restart barter-web
  2) Excel import (fayl serverga yuklangach):
              cd $APP_DIR && sudo -u barter .venv/bin/python manage.py \\
                import_barter_excel /tmp/txt_barter_tozalangan.xlsx --dry-run
  3) Loglar:  sudo journalctl -u barter-web -f
              sudo journalctl -u barter-bot -f
================================================================
DONE
