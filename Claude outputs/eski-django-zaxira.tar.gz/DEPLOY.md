# TXT BARTER BY EZZYJON — serverga joylash

Login va parol bilan ishlaydigan alohida sayt.

Bu qo'llanma Django versiyasini serverga o'rnatib, `https://txtbarter.uz` ko'rinishidagi oddiy sayt qilish uchun. Unda har bir xodim o'z login-paroli bilan kiradi.

## Nima kerak

1. **Server.** Ubuntu 22.04 yoki 24.04, kamida 2 GB RAM, 2 yadro, 20 GB disk. Bu tizim uchun alohida server.
2. **Domen.** `txtbarter.uz` (yoki o'zingiz tanlagan nom). Domen boshqaruv panelida A-yozuv (A record) yaratib, serveringizning IP manzilini ko'rsatasiz — `txtbarter.uz` va `www.txtbarter.uz` uchun ikkitasini.
3. **root yoki sudo huquqi** bilan serverga SSH orqali kirish.

## O'rnatish (bir marta)

Kompyuteringizdan loyihani serverga ko'chirasiz:

```bash
scp -r barter_tizimi root@SERVER_IP:/root/
```

Serverga kiring va o'rnatish skriptini ishga tushiring — domeningizni oxiriga yozing:

```bash
ssh root@SERVER_IP
cd /root/barter_tizimi
sudo bash deploy/setup.sh txtbarter.uz
```

Skript o'zi bajaradigan ishlar:

- kerakli paketlarni o'rnatadi (Python, PostgreSQL, Nginx);
- `barter` nomli tizim foydalanuvchisi va `/opt/barter_tizimi` papkasini yaratadi;
- ma'lumotlar bazasini va unga tasodifiy parol yaratadi;
- `.env` faylini to'ldiradi (SECRET_KEY o'zi generatsiya qilinadi);
- migratsiyalarni bajaradi va statik fayllarni yig'adi;
- `barter-web` (sayt) va `barter-bot` (Telegram) servislarini doimiy ishga tushiradi;
- Nginx sozlamasini qo'yadi;
- oxirida **admin login va parolini** so'raydi — shu bilan saytga kirasiz.

## HTTPS (tavsiya etiladi)

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d txtbarter.uz
```

Sertifikat o'rnatilgach, `/opt/barter_tizimi/.env` faylida `SECURE_COOKIES=True` qilib qo'ying va servisni qayta ishga tushiring:

```bash
sudo nano /opt/barter_tizimi/.env
sudo systemctl restart barter-web
```

## Ma'lumotlarni yuklash

Tozalangan Excel faylni serverga ko'chirib, avval tekshirib ko'ring:

```bash
scp txt_barter_tozalangan.xlsx root@SERVER_IP:/tmp/
ssh root@SERVER_IP
cd /opt/barter_tizimi
sudo -u barter .venv/bin/python manage.py import_barter_excel /tmp/txt_barter_tozalangan.xlsx --dry-run
```

Natijada "458 yangi, 0 xato" chiqsa, `--dry-run` ni olib tashlab qayta ishga tushiring.

Keyinchalik Excel'ni saytning o'zidan ham yuklash mumkin: **Barterlar → Import**.

## Xodimlarni qo'shish

Saytga admin sifatida kiring va **Foydalanuvchilar → Yangi foydalanuvchi**:

- F.I.SH, login va parolni siz belgilaysiz va xodimga aytasiz;
- rol: **Admin** (hammasini ko'radi va o'chira oladi) yoki **Menejer**;
- menejerga TJMlarini belgilaysiz — u faqat o'sha obyektlarni ko'radi.

Xodim tushum kiritgan bo'lsa, uni o'chirish mumkin emas — tarix saqlanishi uchun tizim uni faqat bloklaydi. Kim nima qilgani **Audit log** bo'limida IP manzili bilan yozib boriladi.

## Telegram

Saytdagi **Bot sozlamalari** bo'limiga token va chat ID larni kiritasiz, "Test xabari" bilan tekshirasiz. `barter-bot` servisi allaqachon ishlab turgani uchun kunlik va haftalik hisobot belgilangan vaqtda o'zi yuboriladi, `/bugun`, `/hafta`, `/qarz` buyruqlari ham ishlaydi.

## Kundalik ishlatish

```bash
# Loglar
sudo journalctl -u barter-web -f
sudo journalctl -u barter-bot -f

# Qayta ishga tushirish
sudo systemctl restart barter-web

# Kodni yangilaganda (yangi fayllarni /opt/barter_tizimi ga ko'chirgach)
sudo bash /opt/barter_tizimi/deploy/update.sh
```

## Zaxira nusxa

Bazani har kuni saqlab turish uchun cron yozuvini qo'shing:

```bash
sudo crontab -e
# quyidagi qatorni qo'shing:
0 2 * * * /opt/barter_tizimi/deploy/backup.sh
```

Nusxalar `/var/backups/barter/` papkasida 30 kun saqlanadi. Tiklash:

```bash
gunzip -c /var/backups/barter/barter_2026-09-18.sql.gz | sudo -u postgres psql barter
```

## Nosozliklar

| Belgi | Nima qilish |
|---|---|
| Sayt ochilmaydi | `sudo systemctl status barter-web` va `sudo journalctl -u barter-web -n 50` |
| 400 Bad Request | `.env` dagi `ALLOWED_HOSTS` ichida domeningiz borligini tekshiring |
| Forma yuborilmaydi (CSRF xatosi) | `.env` dagi `CSRF_TRUSTED_ORIGINS` da `https://domen` borligini tekshiring |
| Dizayn buzilgan | `sudo -u barter .venv/bin/python manage.py collectstatic --noinput` |
| Bot jim | `sudo journalctl -u barter-bot -n 50`, token va chat ID ni tekshiring |
| Import 413 xatosi | Nginx'da `client_max_body_size` allaqachon 25M; fayl kattaroq bo'lsa oshiring |
