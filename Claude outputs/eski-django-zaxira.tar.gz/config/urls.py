from django.contrib import admin
from django.urls import include, path

admin.site.site_header = "TXT Barter — boshqaruv"
admin.site.site_title = "TXT Barter"
admin.site.index_title = "Ma'lumotlar"

urlpatterns = [
    path("django-admin/", admin.site.urls),
    path("", include("accounts.urls")),
    path("audit/", include("audit.urls")),
    path("bot/", include("telegram_bot.urls")),
    path("", include("barter.urls")),
]

handler403 = "barter.views.permission_denied"
