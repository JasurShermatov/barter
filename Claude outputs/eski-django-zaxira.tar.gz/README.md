# TXT BARTER BY EZZYJON

Qurilish kompaniyasi uchun barter shartnomalari, material/ish hajmi (abyom) tushumlari va qoldiq qarzni hisoblash tizimi. Django monolit: backend va sahifalar bitta loyihada, Telegram bot alohida jarayon.

## Bo'limlar

| Bo'lim | Nima qiladi | Kim ko'radi |
|---|---|---|
| Dashboard | 4 ta KPI, TJM bo'yicha qarzdorlik, eng katta qoldiqlar, so'nggi tushumlar | hamma |
| Barterlar | Qidiruv, filtrlar, Excel export/import, shartnoma oynasi (Izoh / Tushum / Yopish) | hamma (import — admin) |
| To'lovlar | Tushumlar tarixi, oy/kun/TJM/tur/operator filtri, o'chirish (qoldiq qaytadi) | hamma (o'chirish — admin) |
| Trend va tahlil | 3–24 oylik grafiklar va jadval | hamma |
| Oylik hisobot | Oy tushumi, o'tgan oyga nisbatan %, TJM kesimida qoldiq va qarzdorlik, Excel | hamma |
| Foydalanuvchilar | Admin/Menejer, TJM biriktirish | admin |
| Audit log | Kirish, tushum, o'chirish, yopish, import va boshqa amallar, IP bilan | admin |
| Bot sozlamalari | Token, chat ID, kunlik/haftalik hisobot, darhol xabarlar | admin |

Menejer faqat o'ziga biriktirilgan TJMlardagi shartnomalarni ko'radi va ular bilan ishlaydi.

## Tez ishga tushirish (lokal)

Python 3.11+ kerak.

```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# Tez sinab ko'rish uchun .env ichida:  DB_ENGINE=sqlite  DEBUG=True  SECURE_COOKIES=False

python manage.py makemigrations accounts barter audit telegram_bot
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

`http://127.0.0.1:8000/kirish/` ga kiring. Superuser avtomatik admin hisoblanadi.

> **Migratsiyalar:** loyiha migratsiya fayllarisiz keladi. `makemigrations` ni **bir marta** ishga tushiring va hosil bo'lgan `*/migrations/0001_initial.py` fayllarini git'ga qo'shing. Serverda faqat `migrate` ishlatiladi.

## Excel import

Asl `txt_barter.xlsx` ham, tozalangan `txt_barter_tozalangan.xlsx` ham qabul qilinadi. Tozalangan faylda `Import` varag'i o'qiladi.

```bash
# 1) Avval tekshirish — bazaga hech narsa yozilmaydi
python manage.py import_barter_excel txt_barter_tozalangan.xlsx --dry-run

# 2) Haqiqiy import (audit uchun login ko'rsatish mumkin)
python manage.py import_barter_excel txt_barter_tozalangan.xlsx --user admin
```

Xuddi shu ishni saytda **Barterlar → Import** orqali ham qilish mumkin.

Import qoidalari:

- Ustunlar nomi bo'yicha aniqlanadi (tartibi muhim emas).
- Shartnoma **TJM + raqam** juftligi bo'yicha aniqlanadi. Bir raqam turli TJMlarda bo'lishi mumkin (masalan, `825`).
- «Berilgan chek» → `Boshlang'ich chek (import)` turidagi tushum. Qoldiq = umumiy − barcha tushumlar.
- Qoldig'i 0 bo'lgan qatorlar yopilgan holatda import qilinadi.
- Qayta import xavfsiz: yangi nusxa yaratilmaydi. Tizimda haqiqiy tushum kiritilgan shartnomalarning summalari Exceldan **o'zgartirilmaydi** (ogohlantirish chiqadi).
- To'liq dublikat qatorlar o'tkazib yuboriladi.
- Avtomatik tuzatiladi: matn ko'rinishidagi summalar, 4 xil telefon formati, `23,12,2025` kabi sanalar, TJM nomidagi qo'shtirnoqlar, kirillcha harfli raqamlar (`13П`), `GAZABLOK → GAZOBLOK`.

Hom ashyo guruhlari (`barter/importer/cleaning.py` → `MATERIAL_GROUPS`) taxminiy. Kerak bo'lsa shu yerda yoki tozalangan Excelning `HOM GURUHI` ustunida o'zgartiring.

## Qoldiq summa va qarzdorlik

Tizim ikki xil summani alohida yuritadi:

- **Qoldiq summa** = umumiy summa − yopilgan qism. Bu uyning hali to'lanmagan (yetkazib berilmagan) qolgan qismi.
- **Qarzdorlik** = grafik bo'yicha muddati o'tib, to'lanmay qolgan summa. Boshlang'ich qiymati Exceldagi «OYLIK QARZDORLIK» ustunidan olinadi (`Contract.monthly_amount`), hozirgi holati `Contract.debt_amount` maydonida saqlanadi.

Qoidalar:

- Tushum kiritilganda **avval qarzdorlik yopiladi**, qoldiq summa esa har doim kamayadi.
- Qarzdorlik hech qachon qoldiqdan oshmaydi; shartnoma yopilsa 0 bo'ladi.
- Tushum o'chirilsa, qarzdorlik ham qaytadi (hammasi `recalculate()` da qayta hisoblanadi).
- Qarzdorlikni qo'lda o'zgartirish: shartnomani tahrirlashda «Qarzdorlik summasi» maydoni. Shunda `debt_set_at` yangilanadi va keyingi tushumlar shu vaqtdan boshlab hisoblanadi.

## Pul mantig'i

Barcha o'zgarishlar `barter/services.py` orqali o'tadi (atomik tranzaksiya + qatorni qulflash + audit):

- **Tushum** qoldiqdan katta bo'la olmaydi va avval qarzdorlikni yopadi. Qoldiq 0 bo'lsa, shartnoma avtomatik yopiladi (formadagi belgi bilan boshqariladi).
- **Tushumni o'chirish** (faqat admin) qoldiqni tiklaydi. Agar shartnoma «Majburiyat bajarildi» sababi bilan yopilgan bo'lsa, qayta ochiladi.
- **Yopish sabablari:** majburiyat bajarildi (qoldiq 0 bo'lishi shart), uy qaytarildi, bekor qilindi (izoh majburiy). Yopilgan shartnoma qoldig'i qarzdorlik hisobiga kirmaydi.
- `paid_amount`, `remaining_amount`, `last_payment_at` har doim `Contract.recalculate()` bilan tushumlardan qayta hisoblanadi.

## Telegram bot

1. @BotFather → `/newbot` → token oling.
2. Saytda **Bot sozlamalari** → token va chat ID larni kiriting → Saqlash → «Test xabari».
3. Bot jarayonini ishga tushiring:

```bash
python manage.py run_bot
```

Bot quyidagilarni bajaradi:

- **Kunlik hisobot** belgilangan vaqtda yuboriladi: tushumlar, turi bo'yicha, TJM reytingi, yopilgan/yangi shartnomalar, jami qoldiq.
- **Haftalik hisobot** tanlangan kuni yuboriladi, qo'shimcha ravishda top-10 qoldiq bilan.
- **Darhol xabarlar** (ixtiyoriy): yangi tushum va yopilgan shartnoma haqida.
- **Buyruqlar:** `/bugun`, `/kecha`, `/hafta`, `/qarz`, `/qarz Crystal`.

Chat ID ni bilish uchun botga `/start` yozing. Chat ruxsat ro'yxatida bo'lmasa, bot ID ni o'zi aytadi. Guruhga yuborish uchun botni guruhga qo'shing (guruh ID si `-100...` bilan boshlanadi).

Serverga joylash bo'yicha to'liq qo'llanma: **DEPLOY.md**.

## Serverga joylash

### Docker

```bash
cp .env.example .env      # SECRET_KEY, POSTGRES_PASSWORD, ALLOWED_HOSTS ni to'ldiring
docker compose up -d --build
docker compose exec web python manage.py createsuperuser
docker compose cp txt_barter_tozalangan.xlsx web:/app/
docker compose exec web python manage.py import_barter_excel txt_barter_tozalangan.xlsx
```

`bot` servisi Telegram jarayonini alohida konteynerda doimiy ushlab turadi. Migratsiya fayllari git'da bo'lishi shart (yuqoriga qarang).

### systemd (Docker'siz)

`/etc/systemd/system/barter-web.service`:

```ini
[Unit]
Description=Barter web
After=network.target postgresql.service

[Service]
User=barter
WorkingDirectory=/opt/barter_tizimi
ExecStart=/opt/barter_tizimi/.venv/bin/gunicorn config.wsgi:application --bind 127.0.0.1:8000 --workers 3
Restart=always

[Install]
WantedBy=multi-user.target
```

`/etc/systemd/system/barter-bot.service` ham xuddi shunday tuziladi, faqat `ExecStart` qatori boshqacha:

```ini
ExecStart=/opt/barter_tizimi/.venv/bin/python manage.py run_bot
```

Keyin:

```bash
python manage.py collectstatic --noinput
sudo systemctl enable --now barter-web barter-bot
```

Nginx 127.0.0.1:8000 ga proksi qiladi. HTTPS ortida `.env` da `BEHIND_PROXY=True` va `CSRF_TRUSTED_ORIGINS=https://sizning-domen` bo'lishi kerak.

## Tuzilma

```
config/          sozlamalar, URL
accounts/        User (rol + TJMlar), ruxsatlar, foydalanuvchilar sahifasi
barter/          TJM, Supplier, Contract, Transaction, Note
  services.py    pul o'zgarishlari (yagona manba)
  selectors.py   dashboard, trend, oylik hisobot hisoblari
  exports.py     .xlsx eksportlar
  importer/      cleaning.py (Django'siz, test qilinadigan) + runner.py
audit/           AuditLog, kirish/chiqish signallari
telegram_bot/    sozlamalar, hisobot matnlari, run_bot buyrug'i
templates/       sahifalar (HTMX modal: barter/_detail.html)
static/          app.css (qora/oq rejim), app.js
```

Frontend CDN orqali yuklanadi: HTMX 2.0.4, Lucide ikonkalar, Chart.js 4.4.7, Plus Jakarta Sans shrifti. Internetsiz serverda bu fayllarni `static/vendor/` ga yuklab, `templates/base.html` va `templates/reports/trend.html` dagi manzillarni almashtiring.

## Birinchi ishga tushirishda tekshirish ro'yxati

- [ ] `makemigrations` va `migrate` xatosiz o'tdi.
- [ ] Tozalangan fayl bilan `import_barter_excel --dry-run` natijasi: 458 yangi, 0 xato (asl faylda esa 2 ta dublikat o'tkazib yuboriladi).
- [ ] Dashboardda qoldiq summa ≈ 176.81 mlrd, qarzdorlik ≈ 9.60 mlrd (194 ta qarzdor), aktiv shartnomalar 418 ta.
- [ ] Bitta shartnomaga tushum kiritib, keyin uni o'chirib ko'ring — qoldiq ham, qarzdorlik ham joyiga qaytishi kerak.
- [ ] Menejer yaratib, faqat unga biriktirilgan TJMlar ko'rinishini tekshiring.
- [ ] **CA-456 (MURATOV ABDUQODIR, 12.08 mlrd)** summasini qo'lda tasdiqlang: bu umumiy qarzning 6.8% i.
