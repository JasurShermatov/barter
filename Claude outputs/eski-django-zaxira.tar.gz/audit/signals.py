from django.contrib.auth.signals import user_logged_in, user_logged_out, user_login_failed
from django.dispatch import receiver

from .models import AuditLog
from .utils import log_action


@receiver(user_logged_in)
def on_login(sender, request, user, **kwargs):
    log_action(request, AuditLog.Action.LOGIN, user.display_name, user=user)


@receiver(user_logged_out)
def on_logout(sender, request, user, **kwargs):
    if user is not None:
        log_action(request, AuditLog.Action.LOGOUT, user.display_name, user=user)


@receiver(user_login_failed)
def on_login_failed(sender, credentials, request=None, **kwargs):
    name = (credentials or {}).get("username", "")
    log_action(request, AuditLog.Action.LOGIN_FAILED, f"Login: {name}", username=name)
