from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import render

from accounts.permissions import admin_required

from .models import AuditLog


@admin_required
def audit_list(request):
    qs = AuditLog.objects.select_related("user")
    user_q = request.GET.get("user", "").strip()
    action = request.GET.get("action", "")
    if user_q:
        qs = qs.filter(
            Q(username__icontains=user_q) | Q(user__full_name__icontains=user_q) | Q(detail__icontains=user_q)
        )
    if action:
        qs = qs.filter(action=action)
    page = Paginator(qs, 50).get_page(request.GET.get("page"))
    return render(
        request,
        "audit/list.html",
        {
            "page": page,
            "total": AuditLog.objects.count(),
            "actions": AuditLog.Action.choices,
            "user_q": user_q,
            "action": action,
        },
    )
