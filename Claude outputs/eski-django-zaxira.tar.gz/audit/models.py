from django.conf import settings
from django.db import models
from django.utils import timezone


class AuditLog(models.Model):
    class Action(models.TextChoices):
        LOGIN = "kirish", "Kirish"
        LOGIN_FAILED = "kirish_xato", "Kirish xatosi"
        LOGOUT = "chiqish", "Chiqish"
        PAYMENT = "tolov", "Tushum"
        PAYMENT_DELETE = "tolov_ochirish", "Tushum o'chirildi"
        NOTE = "izoh", "Izoh"
        CONTRACT_CREATE = "shartnoma_yangi", "Yangi shartnoma"
        CONTRACT_EDIT = "shartnoma_tahrir", "Shartnoma tahriri"
        CLOSE = "yopish", "Shartnoma yopildi"
        REOPEN = "qayta_ochish", "Qayta ochildi"
        IMPORT = "import", "Import"
        EXPORT = "export", "Export"
        USER_CREATE = "user_yangi", "Yangi foydalanuvchi"
        USER_EDIT = "user_tahrir", "Foydalanuvchi tahriri"
        USER_DELETE = "user_ochirish", "Foydalanuvchi o'chirildi"
        BOT_SETTINGS = "bot", "Bot sozlamalari"
        BOT_SEND = "bot_yuborish", "Bot xabari"

    created_at = models.DateTimeField(default=timezone.now, db_index=True)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="+"
    )
    username = models.CharField(max_length=150, blank=True, db_index=True)
    action = models.CharField(max_length=30, choices=Action.choices, db_index=True)
    detail = models.TextField(blank=True)
    object_type = models.CharField(max_length=50, blank=True)
    object_id = models.CharField(max_length=50, blank=True)
    ip = models.GenericIPAddressField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Audit yozuvi"
        verbose_name_plural = "Audit log"

    def __str__(self):
        return f"{self.created_at:%d.%m.%Y %H:%M} {self.username} {self.action}"
