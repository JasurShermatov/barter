import ipaddress
import logging

from .models import AuditLog

logger = logging.getLogger(__name__)


def client_ip(request):
    if request is None:
        return None
    forwarded = request.META.get("HTTP_X_FORWARDED_FOR", "")
    candidate = forwarded.split(",")[0].strip() if forwarded else request.META.get("REMOTE_ADDR", "")
    try:
        return str(ipaddress.ip_address(candidate))
    except ValueError:
        return None


def log_action(request, action, detail="", obj=None, user=None, username=None):
    """Audit yozuvi. Xatolik asosiy amalni to'xtatmasligi kerak."""
    try:
        if user is None and request is not None and getattr(request, "user", None) is not None:
            if request.user.is_authenticated:
                user = request.user
        AuditLog.objects.create(
            user=user,
            username=username or (user.username if user else ""),
            action=action,
            detail=str(detail)[:2000],
            object_type=obj._meta.model_name if obj is not None else "",
            object_id=str(obj.pk) if obj is not None else "",
            ip=client_ip(request),
        )
    except Exception:  # pragma: no cover
        logger.exception("Audit yozuvini saqlab bo'lmadi")
