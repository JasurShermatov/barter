from django import forms
from django.contrib.auth import password_validation

from barter.models import TJM

from .models import User


class UserForm(forms.ModelForm):
    password = forms.CharField(
        label="Parol", required=False, strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password"}),
        help_text="Tahrirlashda bo'sh qoldirsangiz, eski parol o'zgarmaydi.",
    )
    tjms = forms.ModelMultipleChoiceField(
        label="TJMlar", queryset=TJM.objects.filter(is_active=True), required=False,
        widget=forms.CheckboxSelectMultiple,
    )

    class Meta:
        model = User
        fields = ["full_name", "username", "role", "tjms", "is_active"]
        labels = {"username": "Login", "is_active": "Faol (tizimga kira oladi)"}
        help_texts = {"username": ""}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["full_name"].required = True
        if self.instance.pk is None:
            self.fields["password"].required = True
            self.fields["password"].help_text = ""

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        qs = User.objects.filter(username__iexact=username).exclude(pk=self.instance.pk)
        if qs.exists():
            raise forms.ValidationError("Bu login band.")
        return username

    def clean(self):
        data = super().clean()
        if data.get("role") == User.Role.MANAGER and not data.get("tjms"):
            self.add_error("tjms", "Menejerga kamida bitta TJM biriktiring.")
        pwd = data.get("password")
        if pwd:
            try:
                password_validation.validate_password(pwd, self.instance)
            except forms.ValidationError as exc:
                self.add_error("password", exc)
        return data

    def save(self, commit=True):
        user = super().save(commit=False)
        if self.cleaned_data.get("password"):
            user.set_password(self.cleaned_data["password"])
        if commit:
            user.save()
            self.save_m2m()
        return user
