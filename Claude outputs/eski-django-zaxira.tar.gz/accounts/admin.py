from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import User


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ("username", "full_name", "role", "is_active")
    list_filter = ("role", "is_active")
    filter_horizontal = ("tjms", "groups", "user_permissions")
    fieldsets = UserAdmin.fieldsets + (("Barter tizimi", {"fields": ("full_name", "role", "tjms")}),)
