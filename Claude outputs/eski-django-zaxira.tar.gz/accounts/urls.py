from django.contrib.auth import views as auth_views
from django.urls import path

from . import views

app_name = "accounts"
urlpatterns = [
    path("kirish/", views.LoginView.as_view(), name="login"),
    path("chiqish/", auth_views.LogoutView.as_view(), name="logout"),
    path("foydalanuvchilar/", views.user_list, name="users"),
    path("foydalanuvchilar/yangi/", views.user_form, name="user_create"),
    path("foydalanuvchilar/<int:pk>/", views.user_form, name="user_edit"),
    path("foydalanuvchilar/<int:pk>/ochirish/", views.user_delete, name="user_delete"),
]
