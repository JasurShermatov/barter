from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN = "admin", "Admin"
        MANAGER = "manager", "Menejer"

    full_name = models.CharField("F.I.SH", max_length=150, blank=True)
    role = models.CharField("Rol", max_length=20, choices=Role.choices, default=Role.MANAGER)
    tjms = models.ManyToManyField(
        "barter.TJM", blank=True, related_name="managers", verbose_name="Biriktirilgan TJMlar"
    )

    class Meta:
        verbose_name = "Foydalanuvchi"
        verbose_name_plural = "Foydalanuvchilar"
        ordering = ["full_name", "username"]

    @property
    def is_admin(self) -> bool:
        return self.is_superuser or self.role == self.Role.ADMIN

    @property
    def display_name(self) -> str:
        return self.full_name or self.username

    def __str__(self):
        return self.display_name
