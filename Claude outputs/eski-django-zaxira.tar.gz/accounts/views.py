from django.contrib import messages
from django.contrib.auth import views as auth_views
from django.db.models import Count, Q
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from audit.models import AuditLog
from audit.utils import log_action

from .forms import UserForm
from .models import User
from .permissions import admin_required


class LoginView(auth_views.LoginView):
    template_name = "registration/login.html"
    redirect_authenticated_user = True


@admin_required
def user_list(request):
    users = User.objects.prefetch_related("tjms").annotate(tx_count=Count("transactions"))
    q = request.GET.get("q", "").strip()
    if q:
        users = users.filter(Q(full_name__icontains=q) | Q(username__icontains=q))
    return render(request, "accounts/users.html", {"users": users, "q": q, "total": User.objects.count()})


@admin_required
def user_form(request, pk=None):
    instance = get_object_or_404(User, pk=pk) if pk else None
    form = UserForm(request.POST or None, instance=instance)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        tjm_names = ", ".join(t.name for t in user.tjms.all()) or "—"
        action = AuditLog.Action.USER_EDIT if instance else AuditLog.Action.USER_CREATE
        log_action(request, action, f"{user.display_name} ({user.username}) | {user.get_role_display()} | {tjm_names}", obj=user)
        messages.success(request, "Foydalanuvchi saqlandi.")
        return redirect("accounts:users")
    return render(request, "accounts/user_form.html", {"form": form, "obj": instance})


@admin_required
@require_POST
def user_delete(request, pk):
    user = get_object_or_404(User, pk=pk)
    if user.pk == request.user.pk:
        messages.error(request, "O'zingizni o'chira olmaysiz.")
        return redirect("accounts:users")
    name = f"{user.display_name} ({user.username})"
    if user.transactions.exists():
        # Tarix yo'qolmasligi uchun o'chirish o'rniga bloklaymiz
        user.is_active = False
        user.save(update_fields=["is_active"])
        log_action(request, AuditLog.Action.USER_DELETE, f"{name} — bloklandi (kiritgan tushumlari bor)")
        messages.warning(request, f"{name} kiritgan tushumlari bor, shuning uchun o'chirilmadi, bloklandi.")
    else:
        user.delete()
        log_action(request, AuditLog.Action.USER_DELETE, name)
        messages.success(request, f"{name} o'chirildi.")
    return redirect("accounts:users")
