from functools import wraps

from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied


def admin_required(view):
    """Faqat Admin rolidagi foydalanuvchilar uchun."""

    @login_required
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_admin:
            raise PermissionDenied("Bu bo'lim faqat admin uchun.")
        return view(request, *args, **kwargs)

    return wrapper


def visible_tjms(user):
    from barter.models import TJM

    if user.is_admin:
        return TJM.objects.filter(is_active=True)
    return user.tjms.filter(is_active=True)


def visible_contracts(user, qs=None):
    """Menejer faqat o'ziga biriktirilgan TJMlardagi shartnomalarni ko'radi."""
    from barter.models import Contract

    if qs is None:
        qs = Contract.objects.all()
    if user.is_admin:
        return qs
    return qs.filter(tjm__in=user.tjms.all())
