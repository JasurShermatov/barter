/* Barter tizimi — kichik interaktivlik (framework'siz, HTMX bilan birga) */
(function () {
  "use strict";
  var root = document.documentElement;

  function icons() {
    if (window.lucide) window.lucide.createIcons();
  }

  /* ---------- mavzu (qora / oq rejim) ---------- */
  function applyThemeLabel() {
    var dark = root.dataset.theme !== "light";
    document.querySelectorAll("[data-theme-label]").forEach(function (el) {
      el.textContent = dark ? "Oq rejim" : "Qora rejim";
    });
    document.querySelectorAll("[data-theme-icon]").forEach(function (el) {
      // lucide <i> ni <svg> ga almashtiradi; svg da .hidden xossasi yo'q, shuning uchun atribut
      el.toggleAttribute("hidden", el.getAttribute("data-theme-icon") !== (dark ? "sun" : "moon"));
    });
  }

  /* ---------- modal ---------- */
  var modal, body, dirty = false;

  function openModal(url) {
    if (!modal || !window.htmx) { window.location.href = url; return; }
    body.innerHTML = '<div class="modal-loading">Yuklanmoqda…</div>';
    modal.hidden = false;
    document.body.style.overflow = "hidden";
    window.htmx.ajax("GET", url, { target: "#modal-body", swap: "innerHTML" });
  }
  function closeModal() {
    if (!modal || modal.hidden) return;
    modal.hidden = true;
    document.body.style.overflow = "";
    body.innerHTML = "";
    var url = new URL(window.location.href);
    if (url.searchParams.has("open")) {
      url.searchParams.delete("open");
      history.replaceState(null, "", url.toString());
    }
    if (dirty) window.location.reload();
  }
  window.openContract = openModal;

  /* ---------- tablar (modal ichida) ---------- */
  function initTabs(scope) {
    (scope || document).querySelectorAll("[data-tabs]").forEach(function (box) {
      var active = box.getAttribute("data-active-tab");
      box.querySelectorAll("[data-tab]").forEach(function (b) {
        b.classList.toggle("active", b.getAttribute("data-tab") === active);
      });
      box.querySelectorAll("[data-panel]").forEach(function (p) {
        p.hidden = p.getAttribute("data-panel") !== active;
      });
    });
  }

  /* ---------- bitta click handler ---------- */
  document.addEventListener("click", function (e) {
    var t = e.target;

    if (t.closest("[data-theme-toggle]")) {
      var next = root.dataset.theme === "light" ? "dark" : "light";
      root.dataset.theme = next;
      try { localStorage.setItem("theme", next); } catch (err) { /* private mode */ }
      applyThemeLabel();
      document.dispatchEvent(new CustomEvent("themechange"));
      return;
    }

    if (t.closest("[data-menu]")) { document.body.classList.toggle("nav-open"); return; }
    if (document.body.classList.contains("nav-open") && !t.closest(".sidebar")) {
      document.body.classList.remove("nav-open");
    }

    if (t.closest("[data-close]")) { closeModal(); return; }

    var tab = t.closest("[data-tab]");
    if (tab) {
      var box = tab.closest("[data-tabs]");
      box.setAttribute("data-active-tab", tab.getAttribute("data-tab"));
      initTabs(box.parentNode);
      return;
    }

    var hist = t.closest("[data-hist]");
    if (hist) {
      var wrap = hist.closest(".history");
      var mode = hist.getAttribute("data-hist");
      wrap.querySelectorAll("[data-hist]").forEach(function (b) { b.classList.toggle("active", b === hist); });
      wrap.querySelectorAll("[data-kind]").forEach(function (li) {
        li.hidden = mode !== "all" && li.getAttribute("data-kind") !== mode;
      });
      return;
    }

    var checkAll = t.closest("[data-check-all]");
    if (checkAll) {
      var boxes = document.querySelectorAll(checkAll.getAttribute("data-check-all") + " label:not([hidden]) input");
      var allOn = Array.prototype.every.call(boxes, function (x) { return x.checked; });
      boxes.forEach(function (x) { x.checked = !allOn; });
      return;
    }

    // Qator ichidagi tugma/forma/havolani bosish qatorni ochmasin
    var interactive = t.closest("a, button, form, input, select, label");
    var opener = t.closest("[data-open-contract]");
    if (opener) {
      var innerControl = interactive && interactive !== opener && opener.contains(interactive);
      if (!innerControl) {
        e.preventDefault();
        openModal(opener.getAttribute("data-open-contract"));
        return;
      }
    }

    var row = t.closest("tr[data-href]");
    if (row && !interactive) window.location.href = row.getAttribute("data-href");
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeModal();
  });

  /* ---------- summa maydonlari: 1250000 -> 1 250 000 ---------- */
  document.addEventListener("input", function (e) {
    var el = e.target;
    if (el.matches("[data-money]")) {
      var raw = el.value.replace(/[^\d,.]/g, "");
      var parts = raw.split(/[,.]/);
      var intPart = parts[0].replace(/^0+(?=\d)/, "").replace(/\B(?=(\d{3})+(?!\d))/g, " ");
      el.value = parts.length > 1 ? intPart + "," + parts[1].slice(0, 2) : intPart;
      return;
    }
    if (el.matches("[data-filter-checks]")) {
      var q = el.value.toLowerCase();
      document.querySelectorAll(el.getAttribute("data-filter-checks") + " label").forEach(function (l) {
        l.hidden = !!q && l.textContent.toLowerCase().indexOf(q) === -1;
      });
    }
  });

  /* ---------- filtrlar o'zgarganda formani yuborish ---------- */
  document.addEventListener("change", function (e) {
    var el = e.target;
    var form = el.closest("form[data-autosubmit]");
    if (!form || el.matches("input[type=text], input[type=search]")) return;
    var page = form.querySelector("input[name=page]");
    if (page) page.remove();
    if (form.requestSubmit) form.requestSubmit(); else form.submit();
  });

  /* ---------- HTMX hodisalari ---------- */
  document.addEventListener("htmx:afterSwap", function (e) {
    initTabs(e.target);
    icons();
  });
  document.addEventListener("htmx:responseError", function () {
    if (body) body.innerHTML = '<div class="modal-loading">Ma\'lumotni yuklab bo\'lmadi. Sahifani yangilab, qayta urinib ko\'ring.</div>';
  });
  document.addEventListener("contractChanged", function () { dirty = true; });

  /* ---------- ishga tushirish ---------- */
  document.addEventListener("DOMContentLoaded", function () {
    modal = document.getElementById("modal");
    body = document.getElementById("modal-body");
    applyThemeLabel();
    icons();
    initTabs(document);
    var auto = document.querySelector("[data-autoload]");
    if (auto) openModal(auto.getAttribute("data-autoload"));
  });
})();
