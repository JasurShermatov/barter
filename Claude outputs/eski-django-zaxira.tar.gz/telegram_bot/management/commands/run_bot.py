"""
Telegram bot jarayoni:
  • kunlik va haftalik hisobotlarni belgilangan vaqtda yuboradi;
  • ruxsat berilgan chatlarda /bugun, /kecha, /hafta, /qarz buyruqlariga javob beradi.

Ishga tushirish:  python manage.py run_bot
(serverda systemd yoki docker-compose orqali doimiy ishlab turadi)
"""
import logging
import time
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.db import close_old_connections
from django.utils import timezone

from telegram_bot import reports
from telegram_bot.client import TelegramError, broadcast, call, send_message
from telegram_bot.models import BotSettings

logger = logging.getLogger("telegram_bot")


class Command(BaseCommand):
    help = "Telegram bot: rejali hisobotlar va buyruqlar"

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS("Telegram bot ishga tushdi. To'xtatish: Ctrl+C"))
        offset = None
        webhook_cleared_for = None
        while True:
            close_old_connections()
            settings = BotSettings.load()
            if not settings.token:
                time.sleep(30)
                continue
            try:
                self.check_schedule(settings)
            except Exception:
                logger.exception("Rejali hisobotda xato")

            if not settings.commands_enabled:
                time.sleep(30)
                continue
            try:
                if webhook_cleared_for != settings.token:
                    call(settings.token, "deleteWebhook")
                    webhook_cleared_for = settings.token
                updates = call(
                    settings.token, "getUpdates", http_timeout=35,
                    timeout=25, offset=offset, allowed_updates=["message"],
                )
            except TelegramError as exc:
                logger.warning("getUpdates: %s", exc)
                time.sleep(10)
                continue
            for upd in updates:
                offset = upd["update_id"] + 1
                try:
                    self.handle_message(settings, upd.get("message") or {})
                except Exception:
                    logger.exception("Buyruqni bajarishda xato")

    # ------------------------------------------------------------------
    def check_schedule(self, settings):
        now = timezone.localtime()
        today = now.date()
        if not settings.chat_id_list() or now.time() < settings.daily_time:
            return
        if settings.daily_enabled and settings.last_daily_sent != today:
            sent, errors = broadcast(reports.daily_report(today), settings)
            settings.last_daily_sent = today
            settings.save(update_fields=["last_daily_sent", "updated_at"])
            logger.info("Kunlik hisobot: %s ta chat, xatolar: %s", sent, errors)
        if (
            settings.weekly_enabled
            and now.weekday() == settings.weekly_day
            and settings.last_weekly_sent != today
        ):
            sent, errors = broadcast(reports.weekly_report(today), settings)
            settings.last_weekly_sent = today
            settings.save(update_fields=["last_weekly_sent", "updated_at"])
            logger.info("Haftalik hisobot: %s ta chat, xatolar: %s", sent, errors)

    def handle_message(self, settings, message):
        text = (message.get("text") or "").strip()
        chat_id = str((message.get("chat") or {}).get("id", ""))
        if not text.startswith("/") or not chat_id:
            return
        command, _, arg = text.partition(" ")
        command = command.split("@")[0].lower()

        if chat_id not in settings.chat_id_list():
            send_message(
                settings.token, chat_id,
                f"⛔️ Bu chatga ruxsat berilmagan.\nChat ID: <code>{chat_id}</code>\n"
                "Admin uni saytdagi «Bot sozlamalari» bo'limiga qo'shishi kerak.",
            )
            return

        today = timezone.localdate()
        if command in ("/start", "/help", "/yordam"):
            reply = reports.HELP_TEXT
        elif command == "/bugun":
            reply = reports.daily_report(today)
        elif command == "/kecha":
            reply = reports.daily_report(today - timedelta(days=1))
        elif command == "/hafta":
            reply = reports.weekly_report(today)
        elif command == "/qarz":
            reply = reports.debt_report(arg.strip())
        else:
            reply = "Noma'lum buyruq.\n\n" + reports.HELP_TEXT
        send_message(settings.token, chat_id, reply)
