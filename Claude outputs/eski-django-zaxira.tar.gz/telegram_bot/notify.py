"""Sayt ichidagi hodisalar haqida darhol xabar (fon oqimida, so'rovni sekinlashtirmaydi)."""
import logging
import threading

from django.db import close_old_connections

logger = logging.getLogger(__name__)


def _run_async(func, *args):
    def target():
        try:
            func(*args)
        except Exception:
            logger.exception("Telegram xabarini yuborib bo'lmadi")
        finally:
            close_old_connections()

    threading.Thread(target=target, daemon=True).start()


def _send_payment(txn_id):
    from barter.models import Transaction

    from .client import broadcast
    from .models import BotSettings
    from .reports import payment_message

    settings = BotSettings.load()
    if not (settings.is_configured and settings.notify_payments):
        return
    txn = Transaction.objects.select_related("contract__supplier", "contract__tjm", "created_by").filter(pk=txn_id).first()
    if txn:
        broadcast(payment_message(txn), settings)


def _send_new_contract(contract_id):
    from barter.models import Contract

    from .client import broadcast
    from .models import BotSettings
    from .reports import new_contract_message

    settings = BotSettings.load()
    if not (settings.is_configured and settings.notify_new):
        return
    contract = (
        Contract.objects.select_related("supplier", "tjm", "created_by")
        .prefetch_related("supplier__phones")
        .filter(pk=contract_id)
        .first()
    )
    if contract:
        broadcast(new_contract_message(contract), settings)


def _send_closed(contract_id):
    from barter.models import Contract

    from .client import broadcast
    from .models import BotSettings
    from .reports import closed_message

    settings = BotSettings.load()
    if not (settings.is_configured and settings.notify_closed):
        return
    contract = Contract.objects.select_related("supplier", "tjm", "closed_by").filter(pk=contract_id).first()
    if contract and contract.is_closed:
        broadcast(closed_message(contract), settings)


def payment_created(txn_id):
    _run_async(_send_payment, txn_id)


def contract_created(contract_id):
    _run_async(_send_new_contract, contract_id)


def contract_closed(contract_id):
    _run_async(_send_closed, contract_id)
