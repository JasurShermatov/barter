from django.contrib import messages
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from accounts.permissions import admin_required
from audit.models import AuditLog
from audit.utils import log_action

from . import reports
from .client import TelegramError, broadcast, call
from .forms import BotSettingsForm
from .models import BotSettings


@admin_required
def settings_view(request):
    settings = BotSettings.load()
    form = BotSettingsForm(request.POST or None, instance=settings)
    if request.method == "POST" and form.is_valid():
        form.save()
        log_action(request, AuditLog.Action.BOT_SETTINGS, "Bot sozlamalari yangilandi")
        messages.success(request, "Sozlamalar saqlandi.")
        return redirect("telegram_bot:settings")
    return render(request, "telegram_bot/settings.html", {"form": form, "settings": settings})


@admin_required
@require_POST
def test_view(request):
    settings = BotSettings.load()
    try:
        me = call(settings.token, "getMe")
    except TelegramError as exc:
        messages.error(request, f"Bot token ishlamadi: {exc}")
        return redirect("telegram_bot:settings")
    sent, errors = broadcast(f"✅ Test xabari. Bot @{me.get('username')} ishlayapti.", settings)
    if errors:
        messages.error(request, "Ba'zi chatlarga yuborilmadi: " + "; ".join(errors))
    if sent:
        messages.success(request, f"@{me.get('username')} ulandi, {sent} ta chatga test xabari yuborildi.")
    elif not errors:
        messages.warning(request, f"@{me.get('username')} ulandi, lekin Chat ID kiritilmagan.")
    return redirect("telegram_bot:settings")


@admin_required
@require_POST
def send_now(request, kind):
    builders = {"kunlik": reports.daily_report, "haftalik": reports.weekly_report, "qarz": reports.debt_report}
    if kind not in builders:
        messages.error(request, "Noma'lum hisobot turi.")
        return redirect("telegram_bot:settings")
    settings = BotSettings.load()
    if not settings.is_configured:
        messages.error(request, "Avval bot token va Chat ID ni kiriting.")
        return redirect("telegram_bot:settings")
    sent, errors = broadcast(builders[kind](), settings)
    log_action(request, AuditLog.Action.BOT_SEND, f"{kind} hisobot: {sent} ta chat")
    if errors:
        messages.error(request, "Xato: " + "; ".join(errors))
    if sent:
        messages.success(request, f"Hisobot {sent} ta chatga yuborildi.")
    return redirect("telegram_bot:settings")
