from django import forms

from .models import BotSettings


class BotSettingsForm(forms.ModelForm):
    token = forms.CharField(
        label="Bot token", required=False,
        widget=forms.PasswordInput(render_value=False, attrs={"autocomplete": "off"}),
        help_text="Bo'sh qoldirsangiz, avvalgi token saqlanib qoladi.",
    )

    class Meta:
        model = BotSettings
        fields = [
            "token", "chat_ids", "daily_enabled", "daily_time", "weekly_enabled", "weekly_day",
            "notify_payments", "notify_new", "notify_closed", "commands_enabled",
        ]
        widgets = {"daily_time": forms.TimeInput(attrs={"type": "time"}, format="%H:%M")}

    def clean_token(self):
        token = self.cleaned_data.get("token", "").strip()
        return token or self.instance.token

    def clean_chat_ids(self):
        value = self.cleaned_data.get("chat_ids", "")
        ids = [c.strip() for c in value.replace(";", ",").split(",") if c.strip()]
        for c in ids:
            if not c.lstrip("-").isdigit():
                raise forms.ValidationError(f"Chat ID faqat raqamlardan iborat bo'lishi kerak: {c}")
        return ", ".join(ids)
