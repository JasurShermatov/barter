"""Telegramga yuboriladigan hisobot matnlari."""
from datetime import timedelta
from html import escape

from django.db.models import Count, Q, Sum
from django.utils import timezone

from barter.models import Contract, Transaction
from barter.utils import aware, fmt_short, fmt_som


def _payments(start, end):
    return (
        Transaction.objects.filter(operation_date__gte=start, operation_date__lte=end)
        .exclude(kind=Transaction.Kind.OPENING)
    )


def _debt_totals():
    return Contract.objects.filter(is_closed=False).aggregate(
        remaining=Sum("remaining_amount"),
        debt=Sum("debt_amount"),
        debtors=Count("id", filter=Q(debt_amount__gt=0)),
        count=Count("id"),
    )


def _period_block(start, end):
    pays = _payments(start, end)
    agg = pays.aggregate(s=Sum("amount"), c=Count("id"))
    by_tjm = (
        pays.values("contract__tjm__name").annotate(s=Sum("amount"), c=Count("id")).order_by("-s")[:10]
    )
    by_kind = pays.values("kind").annotate(s=Sum("amount")).order_by("-s")
    kinds = dict(Transaction.Kind.choices)
    closed = Contract.objects.filter(
        closed_at__gte=aware(start), closed_at__lt=aware(end + timedelta(days=1))
    )
    closed_agg = closed.aggregate(c=Count("id"), s=Sum("total_amount"))
    new = Contract.objects.filter(
        contract_date__gte=aware(start), contract_date__lt=aware(end + timedelta(days=1))
    ).aggregate(c=Count("id"), s=Sum("total_amount"))

    lines = [
        f"💵 Tushumlar: <b>{agg['c'] or 0}</b> ta — <b>{fmt_som(agg['s'])} so'm</b>",
    ]
    for row in by_kind:
        lines.append(f"   • {escape(kinds.get(row['kind'], row['kind']))}: {fmt_short(row['s'])}")
    lines.append(f"✅ Yopilgan shartnomalar: <b>{closed_agg['c'] or 0}</b> ta ({fmt_short(closed_agg['s'])})")
    lines.append(f"🆕 Yangi shartnomalar: <b>{new['c'] or 0}</b> ta ({fmt_short(new['s'])})")
    if by_tjm:
        lines.append("")
        lines.append("🏗 <b>TJM bo'yicha tushum</b>")
        for i, row in enumerate(by_tjm, 1):
            lines.append(f"{i}. {escape(row['contract__tjm__name'])} — {fmt_short(row['s'])} ({row['c']} ta)")
    return lines


def daily_report(day=None):
    day = day or timezone.localdate()
    debt = _debt_totals()
    lines = [f"📊 <b>TXT Barter — kunlik hisobot — {day:%d.%m.%Y}</b>", ""]
    lines += _period_block(day, day)
    lines += [
        "",
        f"📌 Aktiv shartnomalar: <b>{debt['count'] or 0}</b> ta",
        f"💰 Qoldiq summa: <b>{fmt_short(debt['remaining'])}</b>",
        f"🔴 Qarzdorlik (grafik bo'yicha): <b>{fmt_short(debt['debt'])}</b> — {debt['debtors'] or 0} ta qarzdor",
    ]
    return "\n".join(lines)


def weekly_report(end=None):
    end = end or timezone.localdate()
    start = end - timedelta(days=6)
    debt = _debt_totals()
    lines = [f"📈 <b>TXT Barter — haftalik hisobot</b>\n{start:%d.%m} — {end:%d.%m.%Y}", ""]
    lines += _period_block(start, end)
    top = (
        Contract.objects.filter(is_closed=False, debt_amount__gt=0)
        .select_related("supplier", "tjm")
        .order_by("-debt_amount")[:10]
    )
    lines += ["", "🔴 <b>Eng katta qarzdorlar (grafik bo'yicha)</b>"]
    for i, c in enumerate(top, 1):
        lines.append(f"{i}. {escape(c.supplier.full_name)} ({escape(c.tjm.name)}, {escape(c.number)}) — {fmt_short(c.debt_amount)}")
    lines += [
        "",
        f"📌 Aktiv shartnomalar: <b>{debt['count'] or 0}</b> ta",
        f"💰 Qoldiq summa: <b>{fmt_short(debt['remaining'])}</b>",
        f"🔴 Qarzdorlik: <b>{fmt_short(debt['debt'])}</b> — {debt['debtors'] or 0} ta qarzdor",
    ]
    return "\n".join(lines)


def debt_report(tjm_query=""):
    qs = Contract.objects.filter(is_closed=False)
    if tjm_query:
        qs = qs.filter(tjm__name__icontains=tjm_query)
    rows = qs.values("tjm__name").annotate(
        c=Count("id"), s=Sum("remaining_amount"), debt=Sum("debt_amount"),
        debtors=Count("id", filter=Q(debt_amount__gt=0)),
    ).order_by("-debt", "-s")
    if not rows:
        return f"«{escape(tjm_query)}» bo'yicha aktiv shartnoma topilmadi."
    total_rem = sum((r["s"] or 0) for r in rows)
    total_debt = sum((r["debt"] or 0) for r in rows)
    lines = ["🏗 <b>TJM bo'yicha qarzdorlik</b>", ""]
    for i, r in enumerate(rows, 1):
        lines.append(
            f"{i}. {escape(r['tjm__name'])} — qarzdorlik <b>{fmt_short(r['debt'])}</b> "
            f"({r['debtors']} ta), qoldiq {fmt_short(r['s'])}"
        )
    lines += ["", f"Jami qarzdorlik: <b>{fmt_short(total_debt)}</b>", f"Jami qoldiq summa: <b>{fmt_short(total_rem)}</b>"]
    return "\n".join(lines)


def payment_message(txn):
    c = txn.contract
    who = txn.created_by.display_name if txn.created_by else "—"
    return (
        f"💵 <b>Yangi tushum</b>\n"
        f"{escape(c.supplier.full_name)}\n"
        f"🏗 {escape(c.tjm.name)} · {escape(c.number)}\n"
        f"Summa: <b>{fmt_som(txn.amount)} so'm</b> ({escape(txn.get_kind_display())})\n"
        f"Qoldiq: {fmt_som(c.remaining_amount)} so'm"
        + (f" · qarzdorlik: {fmt_som(c.debt_amount)} so'm" if c.debt_amount else "") + "\n"
        f"👤 {escape(who)}" + (f"\n📝 {escape(txn.note)}" if txn.note else "")
    )


def new_contract_message(contract):
    who = contract.created_by.display_name if contract.created_by else "—"
    lines = [
        "🆕 <b>Yangi barter shartnomasi</b>",
        escape(contract.supplier.full_name),
        f"🏗 {escape(contract.tjm.name)} · {escape(contract.number)}",
        f"Umumiy summa: <b>{fmt_som(contract.total_amount)} so'm</b>",
    ]
    if contract.material_type:
        lines.append(f"Hom ashyo: {escape(contract.material_type)}")
    if contract.paid_amount:
        lines.append(f"Berilgan chek: {fmt_som(contract.paid_amount)} so'm")
    lines.append(f"Qoldiq: {fmt_som(contract.remaining_amount)} so'm")
    if contract.debt_amount:
        lines.append(f"Qarzdorlik: {fmt_som(contract.debt_amount)} so'm")
    phones = contract.supplier.phone_list
    if phones:
        lines.append("📞 " + ", ".join(escape(p) for p in phones))
    lines.append(f"👤 {escape(who)}")
    return "\n".join(lines)


def closed_message(contract):
    who = contract.closed_by.display_name if contract.closed_by else "—"
    return (
        f"✅ <b>Shartnoma yopildi</b>\n"
        f"{escape(contract.supplier.full_name)}\n"
        f"🏗 {escape(contract.tjm.name)} · {escape(contract.number)}\n"
        f"Umumiy summa: {fmt_som(contract.total_amount)} so'm\n"
        f"Sabab: {escape(contract.get_close_reason_display())}\n"
        f"👤 {escape(who)}"
    )


HELP_TEXT = (
    "🤖 <b>TXT Barter — hisobot boti</b>\n\n"
    "/bugun — bugungi hisobot\n"
    "/kecha — kechagi hisobot\n"
    "/hafta — oxirgi 7 kun\n"
    "/qarz — TJM bo'yicha qoldiq qarz\n"
    "/qarz Crystal — bitta TJM bo'yicha"
)
