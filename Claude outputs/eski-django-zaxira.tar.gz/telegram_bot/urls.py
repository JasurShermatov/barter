from django.urls import path

from . import views

app_name = "telegram_bot"
urlpatterns = [
    path("", views.settings_view, name="settings"),
    path("test/", views.test_view, name="test"),
    path("yuborish/<str:kind>/", views.send_now, name="send"),
]
