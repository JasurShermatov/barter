"""Telegram Bot API bilan ishlash (requests orqali, qo'shimcha kutubxonasiz)."""
import logging

import requests

logger = logging.getLogger(__name__)
API_URL = "https://api.telegram.org/bot{token}/{method}"
LIMIT = 4000


class TelegramError(Exception):
    pass


def call(token, method, http_timeout=15, **params):
    if not token:
        raise TelegramError("Bot token kiritilmagan")
    try:
        resp = requests.post(API_URL.format(token=token, method=method), json=params, timeout=http_timeout)
    except requests.RequestException as exc:
        raise TelegramError(f"Telegramga ulanib bo'lmadi: {exc}") from exc
    try:
        data = resp.json()
    except ValueError as exc:
        raise TelegramError(f"Telegram javobi noto'g'ri: {resp.text[:200]}") from exc
    if not data.get("ok"):
        raise TelegramError(data.get("description") or "Noma'lum xato")
    return data["result"]


def split_message(text, limit=LIMIT):
    parts, current = [], ""
    for line in text.split("\n"):
        if len(current) + len(line) + 1 > limit and current:
            parts.append(current)
            current = ""
        current += line + "\n"
    if current.strip():
        parts.append(current)
    return parts


def send_message(token, chat_id, text):
    for part in split_message(text):
        call(token, "sendMessage", chat_id=chat_id, text=part, parse_mode="HTML",
             disable_web_page_preview=True)


def broadcast(text, settings=None):
    """Barcha chat ID larga yuboradi. Qaytaradi: (yuborilganlar_soni, xatolar)."""
    from .models import BotSettings

    settings = settings or BotSettings.load()
    sent, errors = 0, []
    for chat_id in settings.chat_id_list():
        try:
            send_message(settings.token, chat_id, text)
            sent += 1
        except TelegramError as exc:
            logger.warning("Telegram %s: %s", chat_id, exc)
            errors.append(f"{chat_id}: {exc}")
    return sent, errors
