from datetime import time

from django.db import models


class BotSettings(models.Model):
    """Yagona yozuv (pk=1). BotSettings.load() orqali olinadi."""

    WEEKDAYS = [
        (0, "Dushanba"), (1, "Seshanba"), (2, "Chorshanba"), (3, "Payshanba"),
        (4, "Juma"), (5, "Shanba"), (6, "Yakshanba"),
    ]

    token = models.CharField("Bot token", max_length=200, blank=True)
    chat_ids = models.CharField(
        "Chat ID lar", max_length=500, blank=True,
        help_text="Vergul bilan ajrating: admin chat va guruh chat. Masalan: 5655089221, -1001234567890",
    )
    daily_enabled = models.BooleanField("Kunlik hisobot", default=True)
    daily_time = models.TimeField("Yuborish vaqti", default=time(20, 0))
    weekly_enabled = models.BooleanField("Haftalik hisobot", default=True)
    weekly_day = models.PositiveSmallIntegerField("Haftalik hisobot kuni", choices=WEEKDAYS, default=5)
    notify_payments = models.BooleanField("Har bir tushum haqida xabar", default=True)
    notify_new = models.BooleanField("Yangi shartnoma qo'shilganda xabar", default=True)
    notify_closed = models.BooleanField("Shartnoma yopilganda xabar", default=True)
    commands_enabled = models.BooleanField("Bot buyruqlari (/bugun, /hafta, /qarz)", default=True)

    last_daily_sent = models.DateField(null=True, blank=True)
    last_weekly_sent = models.DateField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Bot sozlamalari"
        verbose_name_plural = "Bot sozlamalari"

    def __str__(self):
        return "Bot sozlamalari"

    @classmethod
    def load(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

    def chat_id_list(self):
        return [c.strip() for c in self.chat_ids.replace(";", ",").split(",") if c.strip()]

    @property
    def masked_token(self):
        if len(self.token) < 10:
            return "•" * len(self.token)
        return f"{self.token[:4]}{'•' * 12}{self.token[-4:]}"

    @property
    def is_configured(self):
        return bool(self.token and self.chat_id_list())
