from datetime import date, datetime, time
from decimal import Decimal

from django.utils import timezone


def fmt_som(value) -> str:
    """1234567.5 -> '1 234 568'"""
    if value is None:
        return "0"
    return f"{Decimal(value):,.0f}".replace(",", " ")


def fmt_short(value) -> str:
    """Katta summalarni qisqa ko'rinishda: 12.08 mlrd, 584.9 mln."""
    if value is None:
        return "0"
    v = float(value)
    sign = "−" if v < 0 else ""
    v = abs(v)
    if v >= 1_000_000_000:
        return f"{sign}{v / 1_000_000_000:.2f} mlrd"
    if v >= 1_000_000:
        return f"{sign}{v / 1_000_000:.1f} mln"
    if v >= 1_000:
        return f"{sign}{v / 1_000:.0f} ming"
    return f"{sign}{v:.0f}"


def month_start(d: date) -> date:
    return d.replace(day=1)


def add_months(d: date, n: int) -> date:
    m = d.month - 1 + n
    return date(d.year + m // 12, m % 12 + 1, 1)


def aware(d: date) -> datetime:
    return timezone.make_aware(datetime.combine(d, time.min))


def pct_change(current, previous):
    current, previous = float(current or 0), float(previous or 0)
    if previous == 0:
        return None
    return round((current - previous) / previous * 100)


MONTHS_UZ = [
    "", "Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun",
    "Iyul", "Avgust", "Sentyabr", "Oktyabr", "Noyabr", "Dekabr",
]
