from decimal import Decimal

from django.conf import settings
from django.db import models
from django.db.models import Sum
from django.utils import timezone

from .importer.cleaning import GROUP_LABELS, search_key

ZERO = Decimal("0.00")
MONEY = {"max_digits": 18, "decimal_places": 2}


class TJM(models.Model):
    name = models.CharField("Nomi", max_length=120, unique=True)
    is_active = models.BooleanField("Faol", default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]
        verbose_name = "TJM"
        verbose_name_plural = "TJMlar"

    def __str__(self):
        return self.name


class Supplier(models.Model):
    """Barterchi (material/xizmat yetkazib beruvchi)."""

    full_name = models.CharField("F.I.SH", max_length=200)
    search_key = models.CharField(max_length=220, db_index=True, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["full_name"]
        verbose_name = "Barterchi"
        verbose_name_plural = "Barterchilar"

    def save(self, *args, **kwargs):
        self.search_key = search_key(self.full_name)
        super().save(*args, **kwargs)

    @property
    def phone_list(self):
        return [p.phone for p in self.phones.all()]

    def __str__(self):
        return self.full_name


class SupplierPhone(models.Model):
    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE, related_name="phones")
    phone = models.CharField("Telefon", max_length=20, db_index=True)

    class Meta:
        ordering = ["id"]
        constraints = [
            models.UniqueConstraint(fields=["supplier", "phone"], name="uniq_supplier_phone"),
        ]

    def __str__(self):
        return self.phone


class Contract(models.Model):
    class SupplyStatus(models.TextChoices):
        UNKNOWN = "", "Belgilanmagan"
        DOIMIY = "doimiy", "Doimiy"
        ORTA = "orta", "O'rta"
        TOXTAGAN = "toxtagan", "To'xtagan"
        YOQ = "yoq", "Yetkazmayapti (NO)"

    class MaterialGroup(models.TextChoices):
        MATERIAL = "material", GROUP_LABELS["material"]
        TEXNIKA = "texnika", GROUP_LABELS["texnika"]
        XIZMAT = "xizmat", GROUP_LABELS["xizmat"]
        OZIQ = "oziq_ovqat", GROUP_LABELS["oziq_ovqat"]
        BOSHQA = "boshqa", GROUP_LABELS["boshqa"]

    class Currency(models.TextChoices):
        UZS = "UZS", "so'm"
        USD = "USD", "$"

    class CloseReason(models.TextChoices):
        FULFILLED = "bajarildi", "Majburiyat to'liq bajarildi"
        UNIT_RETURNED = "uy_qaytarildi", "Uy (ko'chmas mulk) qaytarildi"
        CANCELLED = "bekor", "Shartnoma bekor qilindi"

    supplier = models.ForeignKey(Supplier, on_delete=models.PROTECT, related_name="contracts", verbose_name="Barterchi")
    tjm = models.ForeignKey(TJM, on_delete=models.PROTECT, related_name="contracts", verbose_name="TJM")
    number = models.CharField("Shartnoma raqami", max_length=50)
    contract_date = models.DateTimeField("Shartnoma sanasi", null=True, blank=True)

    total_amount = models.DecimalField("Umumiy summa", **MONEY)
    paid_amount = models.DecimalField("Yopilgan (chek + tushumlar)", default=ZERO, **MONEY)
    remaining_amount = models.DecimalField("Qoldiq qarz", default=ZERO, db_index=True, **MONEY)
    monthly_amount = models.DecimalField("Qarzdorlik summasi (grafik bo'yicha)", default=ZERO, **MONEY)
    debt_set_at = models.DateTimeField(
        "Qarzdorlik belgilangan vaqt", null=True, blank=True,
        help_text="Shu vaqtdan keyingi tushumlar avval qarzdorlikni yopadi.",
    )
    debt_amount = models.DecimalField(
        "Hozirgi qarzdorlik", default=ZERO, db_index=True,
        help_text="Qarzdorlik summasidan keyingi tushumlar ayirilgan holda; qoldiqdan oshmaydi.",
        **MONEY,
    )
    currency = models.CharField("Valyuta", max_length=3, choices=Currency.choices, default=Currency.UZS)

    material_type = models.CharField("Hom ashyo", max_length=60, blank=True, db_index=True)
    material_group = models.CharField(
        "Hom ashyo guruhi", max_length=20, choices=MaterialGroup.choices, default=MaterialGroup.BOSHQA
    )
    supply_status = models.CharField(
        "Yetkazib berish holati", max_length=20, choices=SupplyStatus.choices, blank=True, default=""
    )

    is_closed = models.BooleanField("Yopilgan", default=False, db_index=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    closed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="+"
    )
    close_reason = models.CharField(max_length=20, choices=CloseReason.choices, blank=True)
    close_note = models.TextField(blank=True)

    last_payment_at = models.DateTimeField("Oxirgi tushum", null=True, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="+"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-remaining_amount"]
        verbose_name = "Shartnoma"
        verbose_name_plural = "Shartnomalar"
        constraints = [
            models.UniqueConstraint(fields=["tjm", "number"], name="uniq_contract_number_per_tjm"),
        ]
        indexes = [models.Index(fields=["tjm", "is_closed"])]

    def __str__(self):
        return f"{self.number} — {self.supplier}"

    def recalculate(self, save=True):
        """paid/remaining/debt/last_payment_at ni tranzaksiyalardan qayta hisoblaydi."""
        real = self.transactions.exclude(kind=Transaction.Kind.OPENING)
        total_paid = self.transactions.aggregate(s=Sum("amount"))["s"] or ZERO
        self.paid_amount = total_paid
        self.remaining_amount = self.total_amount - total_paid
        self.last_payment_at = real.order_by("-created_at").values_list("created_at", flat=True).first()

        # Qarzdorlik: grafik bo'yicha to'lanmagan summa.
        # Belgilangan vaqtdan keyingi tushumlar avval uni yopadi.
        since = self.debt_set_at or self.created_at
        paid_after = ZERO
        if since is not None:
            paid_after = real.filter(created_at__gt=since).aggregate(s=Sum("amount"))["s"] or ZERO
        if self.is_closed:
            self.debt_amount = ZERO
        else:
            self.debt_amount = max(ZERO, min(self.remaining_amount, self.monthly_amount - paid_after))
        if save:
            self.save(update_fields=[
                "paid_amount", "remaining_amount", "debt_amount", "last_payment_at", "updated_at",
            ])

    @property
    def paid_percent(self) -> int:
        if not self.total_amount:
            return 0
        return max(0, min(100, int(self.paid_amount * 100 / self.total_amount)))

    def debt_paid_amount(self):
        """Qarzdorlik belgilangandan keyin yopilgan qismi (shartnoma oynasi uchun)."""
        since = self.debt_set_at or self.created_at
        if since is None or not self.monthly_amount:
            return ZERO
        paid = (
            self.transactions.exclude(kind=Transaction.Kind.OPENING)
            .filter(created_at__gt=since)
            .aggregate(s=Sum("amount"))["s"] or ZERO
        )
        return min(self.monthly_amount, paid)

    @property
    def debt_percent(self) -> int:
        if not self.remaining_amount:
            return 0
        return max(0, min(100, int(self.debt_amount * 100 / self.remaining_amount)))

    @property
    def days_since_payment(self):
        ref = self.last_payment_at
        if ref is None:
            return None
        return (timezone.now() - ref).days


class Transaction(models.Model):
    """Tushum: material yetkazildi, ish hajmi (abyom) bajarildi yoki pul to'landi."""

    class Kind(models.TextChoices):
        MATERIAL = "material", "Material yetkazildi"
        WORK = "abyom", "Ish hajmi (abyom)"
        CASH = "pul", "Pul (naqd / bank)"
        OPENING = "boshlangich", "Boshlang'ich chek (import)"

    contract = models.ForeignKey(Contract, on_delete=models.CASCADE, related_name="transactions")
    amount = models.DecimalField("Summa", **MONEY)
    kind = models.CharField("Turi", max_length=20, choices=Kind.choices, default=Kind.MATERIAL)
    operation_date = models.DateField("Sana", default=timezone.localdate, db_index=True)
    note = models.CharField("Izoh", max_length=255, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="transactions"
    )
    created_at = models.DateTimeField(default=timezone.now, db_index=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Tushum"
        verbose_name_plural = "Tushumlar"

    def __str__(self):
        return f"{self.contract.number}: {self.amount}"

    @property
    def is_opening(self):
        return self.kind == self.Kind.OPENING


class Note(models.Model):
    class Kind(models.TextChoices):
        CALL = "qongiroq", "Qo'ng'iroq qilindi"
        NO_ANSWER = "javobsiz", "Javob bermadi"
        MEETING = "uchrashuv", "Uchrashuv bo'ldi"
        NOTE = "izoh", "Izoh"
        IMPORT = "import", "Excel izohi"

    CALL_KINDS = (Kind.CALL, Kind.NO_ANSWER)

    contract = models.ForeignKey(Contract, on_delete=models.CASCADE, related_name="notes")
    kind = models.CharField(max_length=20, choices=Kind.choices, default=Kind.NOTE)
    text = models.TextField("Izoh", blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="+"
    )
    created_at = models.DateTimeField(default=timezone.now, db_index=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Izoh"
        verbose_name_plural = "Izohlar"

    def __str__(self):
        return f"{self.get_kind_display()}: {self.text[:40]}"
