"""Chiroyli formatlangan .xlsx eksportlar."""
from io import BytesIO

from django.http import HttpResponse
from django.utils import timezone
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

FONT = "Arial"
HEAD_FILL = PatternFill("solid", start_color="1E1B4B")
HEAD_FONT = Font(name=FONT, bold=True, color="FFFFFF", size=10)
BODY_FONT = Font(name=FONT, size=10)
BOLD = Font(name=FONT, size=10, bold=True)
TITLE = Font(name=FONT, size=14, bold=True)
LINE = Border(bottom=Side(style="thin", color="D9D9E3"))
MONEY_FMT = "#,##0;(#,##0);-"


def _sheet(wb, title, heading, columns, start_row=4):
    ws = wb.active
    ws.title = title
    ws["A1"] = heading
    ws["A1"].font = TITLE
    ws["A2"] = f"Yaratildi: {timezone.localtime():%d.%m.%Y %H:%M}"
    ws["A2"].font = Font(name=FONT, size=9, color="6B7280")
    for i, (name, width) in enumerate(columns, 1):
        c = ws.cell(start_row, i, name)
        c.fill, c.font = HEAD_FILL, HEAD_FONT
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.row_dimensions[start_row].height = 30
    ws.freeze_panes = ws.cell(start_row + 1, 1)
    return ws


def _style_row(ws, row, ncols, money_cols=(), date_cols=(), pct_cols=()):
    for c in range(1, ncols + 1):
        cell = ws.cell(row, c)
        cell.font, cell.border = BODY_FONT, LINE
        if c in money_cols:
            cell.number_format = MONEY_FMT
        elif c in date_cols:
            cell.number_format = "dd.mm.yyyy hh:mm"
        elif c in pct_cols:
            cell.number_format = "0%"


def _total_row(ws, row, label_col, sum_cols, first, last, fmt=MONEY_FMT):
    ws.cell(row, label_col, "JAMI").font = BOLD
    for c in sum_cols:
        L = get_column_letter(c)
        cell = ws.cell(row, c, f"=SUBTOTAL(9,{L}{first}:{L}{last})")
        cell.font, cell.number_format = BOLD, fmt


def _response(wb, filename):
    buf = BytesIO()
    wb.save(buf)
    resp = HttpResponse(
        buf.getvalue(),
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    resp["Content-Disposition"] = f'attachment; filename="{filename}"'
    return resp


def _naive(dt):
    return timezone.localtime(dt).replace(tzinfo=None) if dt else None


def export_contracts(qs):
    wb = Workbook()
    cols = [
        ("№", 6), ("Shartnoma raqami", 16), ("Barterchi", 38), ("Telefon", 30), ("Sana", 17),
        ("TJM", 20), ("Hom ashyo", 16), ("Guruh", 20), ("Holat", 14), ("Umumiy summa", 17),
        ("Yopilgan (chek + tushum)", 18), ("Qoldiq summa", 17), ("Qarzdorlik (grafik bo'yicha)", 19),
        ("Oxirgi tushum", 17), ("Yopilgan", 10),
    ]
    ws = _sheet(wb, "Barterlar", "Barter shartnomalari", cols)
    first = row = 5
    qs = qs.select_related("supplier", "tjm").prefetch_related("supplier__phones")
    for i, c in enumerate(qs.iterator(chunk_size=500), 1):
        ws.append([
            i, c.number, c.supplier.full_name, ", ".join(p.phone for p in c.supplier.phones.all()),
            _naive(c.contract_date), c.tjm.name, c.material_type, c.get_material_group_display(),
            c.get_supply_status_display() if c.supply_status else "", float(c.total_amount),
            float(c.paid_amount), f"=J{row}-K{row}", float(c.debt_amount),
            _naive(c.last_payment_at), "Ha" if c.is_closed else "",
        ])
        _style_row(ws, row, len(cols), money_cols=(10, 11, 12, 13), date_cols=(5, 14))
        row += 1
    last = max(row - 1, first)
    _total_row(ws, row, 9, (10, 11, 12, 13), first, last)
    ws.auto_filter.ref = f"A4:{get_column_letter(len(cols))}{last}"
    return _response(wb, f"barterlar_{timezone.localdate():%Y%m%d}.xlsx")


def export_payments(qs):
    wb = Workbook()
    cols = [
        ("Sana", 12), ("Kiritilgan vaqt", 17), ("Barterchi", 38), ("TJM", 20), ("Shartnoma", 16),
        ("Turi", 22), ("Summa (so'm)", 17), ("Izoh", 40), ("Operator", 24), ("Shartnoma holati", 14),
    ]
    ws = _sheet(wb, "Tushumlar", "Tushumlar tarixi", cols)
    first = row = 5
    qs = qs.select_related("contract__supplier", "contract__tjm", "created_by")
    for t in qs.iterator(chunk_size=500):
        ws.append([
            t.operation_date, _naive(t.created_at), t.contract.supplier.full_name, t.contract.tjm.name,
            t.contract.number, t.get_kind_display(), float(t.amount), t.note,
            t.created_by.display_name if t.created_by else "", "Yopilgan" if t.contract.is_closed else "Faol",
        ])
        _style_row(ws, row, len(cols), money_cols=(7,), date_cols=(2,))
        ws.cell(row, 1).number_format = "dd.mm.yyyy"
        row += 1
    last = max(row - 1, first)
    _total_row(ws, row, 6, (7,), first, last)
    ws.auto_filter.ref = f"A4:{get_column_letter(len(cols))}{last}"
    return _response(wb, f"tushumlar_{timezone.localdate():%Y%m%d}.xlsx")


def export_monthly(report):
    wb = Workbook()
    cols = [
        ("TJM", 26), ("Aktiv shartnomalar", 14), ("Qoldiq summa", 18),
        ("Qarzdorlik (grafik bo'yicha)", 19), ("Qarzdorlar soni", 13),
        ("Oy tushumi", 17), ("Tushumlar soni", 12), ("Yopildi (soni)", 12), ("Yopilgan summa", 17),
    ]
    ws = _sheet(wb, "Oylik hisobot", f"Oylik hisobot — {report['label']}", cols, start_row=10)
    cur = report["cur"]
    summary = [
        ("Oy tushumi", float(cur["pay_sum"])), ("Tushumlar soni", cur["pay_count"]),
        ("Yopilgan shartnomalar", cur["closed_count"]), ("Yangi shartnomalar", cur["new_count"]),
        ("Qo'ng'iroqlar", cur["calls"]), ("Aktiv shartnomalar", report["active"]),
        ("Qoldiq summa (hozir)", float(report["remaining"])),
        ("Qarzdorlik (grafik bo'yicha)", float(report["debt"])),
        ("Qarzdorlar soni", report["debtors"]),
    ]
    for i, (label, value) in enumerate(summary):
        r = 3 + i // 2
        col = 1 + (i % 2) * 3
        ws.cell(r, col, label).font = BODY_FONT
        v = ws.cell(r, col + 1, value)
        v.font = BOLD
        if isinstance(value, float):
            v.number_format = MONEY_FMT
    first = row = 11
    for r in report["rows"]:
        ws.append([
            r["tjm"].name, r["active"], float(r["remaining"]), float(r["debt"]), r["debtors"],
            float(r["pay_sum"]), r["pay_count"], r["closed_count"], float(r["closed_sum"]),
        ])
        _style_row(ws, row, len(cols), money_cols=(3, 4, 6, 9))
        row += 1
    last = max(row - 1, first)
    ws.cell(row, 1, "JAMI").font = BOLD
    for c in (2, 3, 4, 5, 6, 7, 8, 9):
        L = get_column_letter(c)
        cell = ws.cell(row, c, f"=SUM({L}{first}:{L}{last})")
        cell.font = BOLD
        if c in (3, 4, 6, 9):
            cell.number_format = MONEY_FMT
    ws.cell(row + 2, 1, "«Qoldiq summa» — uylarning to'lanmagan qolgan summasi. "
                        "«Qarzdorlik» — grafik bo'yicha muddati o'tib to'lanmagan summa.").font = Font(
        name=FONT, size=9, color="6B7280"
    )
    return _response(wb, f"oylik_hisobot_{report['key']}.xlsx")
