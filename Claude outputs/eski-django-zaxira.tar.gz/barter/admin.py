from django.contrib import admin

from .models import TJM, Contract, Note, Supplier, SupplierPhone, Transaction


@admin.register(TJM)
class TJMAdmin(admin.ModelAdmin):
    list_display = ("name", "is_active")
    search_fields = ("name",)


class PhoneInline(admin.TabularInline):
    model = SupplierPhone
    extra = 0


@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    search_fields = ("full_name", "search_key")
    inlines = [PhoneInline]


@admin.register(Contract)
class ContractAdmin(admin.ModelAdmin):
    list_display = ("number", "supplier", "tjm", "total_amount", "remaining_amount", "is_closed")
    list_filter = ("tjm", "is_closed", "material_group", "supply_status")
    search_fields = ("number", "supplier__full_name")
    raw_id_fields = ("supplier",)
    readonly_fields = ("paid_amount", "remaining_amount", "last_payment_at")


@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ("contract", "amount", "kind", "operation_date", "created_by", "created_at")
    list_filter = ("kind",)
    raw_id_fields = ("contract",)


@admin.register(Note)
class NoteAdmin(admin.ModelAdmin):
    list_display = ("contract", "kind", "created_by", "created_at")
    raw_id_fields = ("contract",)
