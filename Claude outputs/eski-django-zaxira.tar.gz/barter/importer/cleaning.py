"""
Excel qatorlarini tozalash — Django'ga bog'liq emas (alohida test qilish mumkin).

Asl fayl (txt_barter.xlsx) va tozalangan fayl bir xil ustun nomlariga ega,
shuning uchun bu funksiyalar ikkalasini ham qabul qiladi (idempotent).
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

# ---------------------------------------------------------------- sarlavhalar
HEADER_ALIASES = {
    "number": ["shartnoma raqami", "shartnoma", "shartnoma №", "contract"],
    "supplier": ["mijoz", "barterchi", "fish", "f.i.sh"],
    "phone": ["telefon raqam", "telefon", "phone"],
    "date": ["sana", "shartnoma sanasi", "date"],
    "tjm": ["tjm nomi", "tjm", "obyekt"],
    "total": ["umumiy summa", "umumiy", "shartnoma summasi"],
    "paid": ["berilgan chek", "chek", "tolangan", "to'langan"],
    "remaining": ["qolgan summa", "qoldiq", "qolgan"],
    "monthly": ["oylik qarzdorlik", "oylik"],
    "note": ["izox", "izoh"],
    "material": ["hom ashyo", "xom ashyo", "material"],
    "material_group": ["hom guruhi", "xom ashyo guruhi", "guruh"],
    "status": ["holati", "holat"],
}
REQUIRED = ["number", "supplier", "tjm", "total"]


def _norm_header(value) -> str:
    s = str(value or "").strip().lower()
    s = s.replace("‘", "'").replace("’", "'").replace("ʻ", "'").replace("ʼ", "'")
    return re.sub(r"\s+", " ", s)


def map_headers(header_row) -> dict[str, int]:
    """Sarlavha qatoridan {maydon: ustun_indeksi} yasaydi."""
    result: dict[str, int] = {}
    normalized = [_norm_header(h) for h in header_row]
    for key, aliases in HEADER_ALIASES.items():
        for idx, h in enumerate(normalized):
            if h in aliases:
                result[key] = idx
                break
    missing = [k for k in REQUIRED if k not in result]
    if missing:
        raise ValueError("Excelda majburiy ustunlar topilmadi: " + ", ".join(missing))
    return result


# ------------------------------------------------------------------ matnlar
APOSTROPHES = "‘’ʻʼ`´′"


def clean_text(value) -> str:
    if value is None:
        return ""
    s = str(value)
    if s.lower() == "nan":
        return ""
    s = unicodedata.normalize("NFC", s)
    for ch in APOSTROPHES:
        s = s.replace(ch, "'")
    s = s.replace("\xa0", " ")
    return re.sub(r"\s+", " ", s).strip()


def clean_person_name(value) -> str:
    return clean_text(value).upper()


def search_key(value) -> str:
    """Qidiruv uchun kalit: katta harf, apostrof va ortiqcha belgilarsiz."""
    s = clean_text(value).upper().replace("'", "")
    return re.sub(r"[^0-9A-ZА-ЯЁЎҚҒҲ ]", "", s)


def clean_tjm(value) -> str:
    s = clean_text(value)
    s = s.strip("\"'«»“”„ ")
    s = s.replace('"', "").replace("«", "").replace("»", "").replace("“", "").replace("”", "")
    return re.sub(r"\s+", " ", s).strip()


def tjm_key(value) -> str:
    return clean_tjm(value).upper()


def clean_contract_number(value) -> str:
    s = clean_text(value)
    if re.fullmatch(r"\d+\.0", s):  # Excel son sifatida saqlagan bo'lsa
        s = s[:-2]
    # Kirillcha harflarni lotinchaga (13П -> 13P, С -> C)
    s = s.translate(str.maketrans("ПСАКРМНТОЕВХ", "PCAKPMHTOEBX"))
    return s.upper()


# ------------------------------------------------------------------- pullar
def parse_money(value) -> Decimal | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float, Decimal)):
        return Decimal(str(value)).quantize(Decimal("0.01"))
    s = str(value).replace("\xa0", "").replace(" ", "").strip()
    if s == "" or s.lower() == "nan":
        return None
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif "," in s:
        head, _, tail = s.rpartition(",")
        s = f"{head.replace(',', '')}.{tail}" if len(tail) <= 2 else s.replace(",", "")
    try:
        return Decimal(s).quantize(Decimal("0.01"))
    except InvalidOperation:
        return None


# ------------------------------------------------------------------ sanalar
DATE_FORMATS = ("%d.%m.%Y %H:%M", "%d.%m.%Y %H:%M:%S", "%d.%m.%Y", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d")


def parse_date(value) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day)
    s = clean_text(value).replace(",", ".").replace("/", ".")
    if not s:
        return None
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


# ---------------------------------------------------------------- telefonlar
def parse_phones(value) -> tuple[list[str], str | None]:
    """'=+998..., +998...', '998901234567', '90 199 00 89 94 449 31 89' kabilarni
    ['+998901990089', '+998944493189'] ko'rinishiga keltiradi.
    Qaytaradi: (telefonlar, muammo_matni yoki None)."""
    if value is None:
        return [], None
    if isinstance(value, float):
        value = str(int(value))
    raw = clean_text(value).lstrip("=")
    if not raw:
        return [], None
    phones: list[str] = []
    problem = None
    for part in re.split(r"[,;/]", raw):
        digits = re.sub(r"\D", "", part)
        if part.strip().startswith("+") and not digits.startswith("998") and 10 <= len(digits) <= 15:
            phone = "+" + digits  # xorijiy raqam (masalan +1...)
            if phone not in phones:
                phones.append(phone)
            continue
        while digits:
            if digits.startswith("998") and len(digits) >= 12:
                chunk, digits = digits[:12], digits[12:]
            elif len(digits) >= 9:
                chunk, digits = "998" + digits[:9], digits[9:]
            else:
                problem = f"Telefonning bir qismi o'qilmadi: {digits}"
                break
            phone = "+" + chunk
            if phone not in phones:
                phones.append(phone)
    if not phones and problem is None:
        problem = f"Telefon o'qilmadi: {raw}"
    return phones, problem


# -------------------------------------------------------------- holat/material
STATUS_MAP = {
    "DOIMIY": "doimiy",
    "ORTA": "orta",
    "O'RTA": "orta",
    "TOXTAGAN": "toxtagan",
    "TO'XTAGAN": "toxtagan",
    "NO": "yoq",
    "YOQ": "yoq",
    "YO'Q": "yoq",
}
STATUS_LABELS = {"doimiy": "DOIMIY", "orta": "O'RTA", "toxtagan": "TO'XTAGAN", "yoq": "NO", "": ""}


def parse_status(value) -> str:
    s = clean_text(value).upper()
    if s in ("DOIMIY", "O'RTA", "TO'XTAGAN", "NO", "ORTA", "TOXTAGAN", "YOQ", "YO'Q"):
        return STATUS_MAP[s]
    # tozalangan fayldagi kodlar
    if s.lower() in STATUS_LABELS:
        return s.lower()
    return ""


MATERIAL_ALIASES = {
    "GAZABLOK": "GAZOBLOK",
    "SALYARKA": "SOLYARKA",
    "KRAYNSHTEYN": "KRANSHTEYN",
    "NO": "",
    "НОН": "NON",
}

MATERIAL_GROUPS = {
    "material": {
        "AKFA", "ALKAFON", "APOLAFKA", "ASFALT", "BAZALT", "BETON", "BETONZAVOD", "BLOK",
        "ESHIK", "FASAD", "G'ISHT", "GAZOBLOK", "IZOLYATSIYA", "KABEL", "KAFEL",
        "KANALIZATSIYA", "KRANSHTEYN", "MDF", "MEBEL", "METAL", "MRAMR", "OYNA", "PANEL",
        "PERILLA", "PLITA", "PROFIL", "PROFNASTIL", "QUM", "ROTBAND", "SANTEXNIKA", "SEMENT",
        "SETKA", "SHAG'AL", "SHEBEN", "SHIT", "SOLYARKA", "SVITILNIK", "TAXTA", "TOSH",
        "XIM DOBAVKA", "ELEKTR", "KONDITSIONER", "VENTILYATSIYA", "LIFT", "ZAPCHAST",
        "XOZMAK", "KARYER", "GAZON", "DARAXT",
    },
    "texnika": {"TEXNIKA", "KRAN", "EKSKOVATOR", "DAMKRAT", "BITOVOY"},
    "xizmat": {
        "ABYOM", "KOTLOVAN", "MALYAR", "STYASHKA", "SVARSHIK", "REKLAMA", "BILBOARD",
        "ARENDA", "MAKLER", "OYLIK", "LOYXA",
    },
    "oziq_ovqat": {"GO'SHT", "NON", "GURUCH", "TUXUM", "PRODUKTA", "ZIRAVOR"},
}
GROUP_LABELS = {
    "material": "Qurilish materiali",
    "texnika": "Texnika",
    "xizmat": "Xizmat / ish hajmi",
    "oziq_ovqat": "Oziq-ovqat",
    "boshqa": "Boshqa",
}
GROUP_BY_LABEL = {v.upper(): k for k, v in GROUP_LABELS.items()}


def parse_material(value) -> str:
    s = clean_text(value).upper()
    return MATERIAL_ALIASES.get(s, s)


def material_group(material: str, explicit=None) -> str:
    if explicit:
        e = clean_text(explicit)
        if e.lower() in GROUP_LABELS:
            return e.lower()
        if e.upper() in GROUP_BY_LABEL:
            return GROUP_BY_LABEL[e.upper()]
    for group, names in MATERIAL_GROUPS.items():
        if material in names:
            return group
    return "boshqa"


# --------------------------------------------------------------- qator natijasi
@dataclass
class CleanRow:
    row_no: int
    number: str
    supplier: str
    supplier_key: str
    phones: list[str]
    contract_date: datetime | None
    tjm: str
    total: Decimal
    paid: Decimal
    remaining: Decimal
    monthly: Decimal
    note: str
    material: str
    material_group: str
    status: str
    problems: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)  # jiddiy: qator import qilinmaydi
    duplicate_of: int | None = None


def _cell(row, mapping, key):
    idx = mapping.get(key)
    if idx is None or idx >= len(row):
        return None
    return row[idx]


def clean_row(row, mapping, row_no: int) -> CleanRow:
    problems: list[str] = []
    errors: list[str] = []

    number_raw = _cell(row, mapping, "number")
    number = clean_contract_number(number_raw)
    if number != clean_text(number_raw).upper() and clean_text(number_raw):
        problems.append(f"Shartnoma raqami o'zgartirildi: {clean_text(number_raw)} → {number}")
    supplier = clean_person_name(_cell(row, mapping, "supplier"))
    tjm = clean_tjm(_cell(row, mapping, "tjm"))
    raw_tjm = clean_text(_cell(row, mapping, "tjm"))
    if raw_tjm and raw_tjm != tjm:
        problems.append(f"TJM nomi tozalandi: {raw_tjm} → {tjm}")

    if not number:
        errors.append("Shartnoma raqami bo'sh")
    if not supplier:
        errors.append("Barterchi ismi bo'sh")
    if not tjm:
        errors.append("TJM bo'sh")

    phones, phone_problem = parse_phones(_cell(row, mapping, "phone"))
    if phone_problem:
        problems.append(phone_problem)

    raw_date = _cell(row, mapping, "date")
    contract_date = parse_date(raw_date)
    if contract_date is None and clean_text(raw_date):
        problems.append(f"Sana o'qilmadi: {clean_text(raw_date)}")
    elif isinstance(raw_date, str) and contract_date and not re.fullmatch(
        r"\d{1,2}\.\d{1,2}\.\d{4} \d{1,2}:\d{2}", clean_text(raw_date)
    ):
        problems.append(f"Sana formati tuzatildi: {clean_text(raw_date)}")

    total = parse_money(_cell(row, mapping, "total"))
    paid = parse_money(_cell(row, mapping, "paid"))
    remaining_file = parse_money(_cell(row, mapping, "remaining"))
    monthly = parse_money(_cell(row, mapping, "monthly")) or Decimal("0.00")

    if total is None:
        errors.append("Umumiy summa o'qilmadi")
        total = Decimal("0.00")
    if paid is None:
        if remaining_file is not None:
            paid = total - remaining_file
        else:
            paid = Decimal("0.00")
    remaining = total - paid
    if remaining_file is not None and abs(remaining_file - remaining) > Decimal("1"):
        problems.append(
            f"Qolgan summa mos emas: faylda {remaining_file:,.0f}, hisob bo'yicha {remaining:,.0f}"
        )
    if paid < 0:
        errors.append("Berilgan chek manfiy")
    if remaining < 0:
        errors.append("Berilgan chek umumiy summadan katta")
    if monthly > remaining and remaining >= 0:
        problems.append("Oylik qarzdorlik qoldiqdan katta")

    material_raw = clean_text(_cell(row, mapping, "material")).upper()
    material = parse_material(material_raw)
    if material_raw and material != material_raw:
        problems.append(f"Hom ashyo nomi birxillashtirildi: {material_raw} → {material or '—'}")
    if not material:
        problems.append("Hom ashyo ko'rsatilmagan")
    group = material_group(material, _cell(row, mapping, "material_group"))

    status_raw = _cell(row, mapping, "status")
    status = parse_status(status_raw)
    if clean_text(status_raw) and not status:
        problems.append(f"Holat tanilmadi: {clean_text(status_raw)}")

    return CleanRow(
        row_no=row_no,
        number=number,
        supplier=supplier,
        supplier_key=search_key(supplier),
        phones=phones,
        contract_date=contract_date,
        tjm=tjm,
        total=total,
        paid=paid,
        remaining=remaining,
        monthly=monthly,
        note=clean_text(_cell(row, mapping, "note")),
        material=material,
        material_group=group,
        status=status,
        problems=problems,
        errors=errors,
    )


def clean_rows(rows) -> list[CleanRow]:
    """rows: sarlavha qatori + ma'lumot qatorlari (tuple/list).
    Bo'sh qatorlarni tashlab yuboradi, dublikatlarni belgilaydi."""
    rows = list(rows)
    if not rows:
        raise ValueError("Excel fayl bo'sh")
    mapping = map_headers(rows[0])
    result: list[CleanRow] = []
    seen: dict[tuple[str, str], CleanRow] = {}
    for i, row in enumerate(rows[1:], start=2):
        if row is None or all(clean_text(c) == "" for c in row):
            continue
        # "JAMI" kabi yig'indi qatorlari: na raqam, na ism bor
        if not clean_text(_cell(row, mapping, "number")) and not clean_text(_cell(row, mapping, "supplier")):
            continue
        item = clean_row(row, mapping, i)
        key = (tjm_key(item.tjm), item.number)
        if item.number and key in seen:
            first = seen[key]
            same = (
                first.supplier_key == item.supplier_key
                and first.total == item.total
                and first.paid == item.paid
            )
            if same:
                item.duplicate_of = first.row_no
                item.problems.append(
                    f"To'liq dublikat ({first.row_no}-qator bilan bir xil) — import qilinmaydi"
                )
                for p in item.phones:
                    if p not in first.phones:
                        first.phones.append(p)
            else:
                item.errors.append(
                    f"Shartnoma raqami {item.number} shu TJMda {first.row_no}-qatorda boshqa ma'lumot bilan bor"
                )
        else:
            seen[key] = item
        result.append(item)
    return result
