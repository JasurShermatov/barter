"""Excel → bazaga import. Qayta ishga tushirsa ham xavfsiz (idempotent)."""
from dataclasses import dataclass, field
from decimal import Decimal

import openpyxl
from django.db import transaction
from django.utils import timezone

from audit.models import AuditLog
from audit.utils import log_action

from ..models import TJM, Contract, Note, Supplier, SupplierPhone, Transaction
from .cleaning import clean_rows, tjm_key

OPENING_NOTE = "Excel import: berilgan chek"


@dataclass
class ImportResult:
    total_rows: int = 0
    created: int = 0
    updated: int = 0
    skipped: int = 0
    tjms_created: list = field(default_factory=list)
    suppliers_created: int = 0
    errors: list = field(default_factory=list)      # (qator, matn)
    warnings: list = field(default_factory=list)    # (qator, matn)
    fixes: int = 0
    dry_run: bool = False
    debt_total: Decimal = Decimal("0")
    arrears_total: Decimal = Decimal("0")

    @property
    def ok(self):
        return not self.errors


def _aware(dt):
    if dt is None:
        return None
    return timezone.make_aware(dt) if timezone.is_naive(dt) else dt


def read_rows(file_or_path):
    wb = openpyxl.load_workbook(file_or_path, read_only=True, data_only=True)
    ws = wb["Import"] if "Import" in wb.sheetnames else wb.worksheets[0]
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    return clean_rows(rows)


def _sync_opening(contract, paid, user):
    """Boshlang'ich chek tranzaksiyasini Excel qiymatiga tenglashtiradi."""
    opening = contract.transactions.filter(kind=Transaction.Kind.OPENING).first()
    if paid > 0:
        if opening is None:
            Transaction.objects.create(contract=contract, amount=paid, kind=Transaction.Kind.OPENING,
                                       note=OPENING_NOTE, created_by=user)
        elif opening.amount != paid:
            opening.amount = paid
            opening.save(update_fields=["amount"])
    elif opening is not None:
        opening.delete()


def _sync_closed(contract):
    if contract.remaining_amount <= 0 and not contract.is_closed:
        contract.is_closed = True
        contract.close_reason = Contract.CloseReason.FULFILLED
        contract.close_note = "Import: qoldiq 0"
        contract.save(update_fields=["is_closed", "close_reason", "close_note", "updated_at"])
    elif contract.remaining_amount > 0 and contract.is_closed and contract.close_reason == Contract.CloseReason.FULFILLED:
        contract.is_closed = False
        contract.close_reason = ""
        contract.close_note = ""
        contract.closed_at = None
        contract.save(update_fields=["is_closed", "close_reason", "close_note", "closed_at", "updated_at"])


def run_import(file_or_path, user=None, dry_run=False, request=None) -> ImportResult:
    result = ImportResult(dry_run=dry_run)
    try:
        rows = read_rows(file_or_path)
    except ValueError as exc:
        result.errors.append((0, str(exc)))
        return result
    except Exception as exc:  # buzuq fayl
        result.errors.append((0, f"Faylni o'qib bo'lmadi: {exc}"))
        return result

    result.total_rows = len(rows)
    tjm_cache = {tjm_key(t.name): t for t in TJM.objects.all()}

    with transaction.atomic():
        for r in rows:
            result.fixes += len(r.problems)
            if r.errors:
                result.errors.extend((r.row_no, e) for e in r.errors)
                continue
            if r.duplicate_of:
                result.skipped += 1
                result.warnings.append((r.row_no, f"{r.number}: {r.duplicate_of}-qatorning dublikati, o'tkazib yuborildi"))
                continue

            key = tjm_key(r.tjm)
            tjm = tjm_cache.get(key)
            if tjm is None:
                tjm = TJM.objects.create(name=r.tjm)
                tjm_cache[key] = tjm
                result.tjms_created.append(r.tjm)

            supplier = Supplier.objects.filter(search_key=r.supplier_key).first()
            if supplier is None:
                supplier = Supplier.objects.create(full_name=r.supplier)
                result.suppliers_created += 1
            for phone in r.phones:
                SupplierPhone.objects.get_or_create(supplier=supplier, phone=phone)

            contract = Contract.objects.filter(tjm=tjm, number=r.number).first()
            if contract is None:
                contract = Contract.objects.create(
                    supplier=supplier, tjm=tjm, number=r.number,
                    contract_date=_aware(r.contract_date),
                    total_amount=r.total, monthly_amount=r.monthly, debt_set_at=timezone.now(),
                    material_type=r.material, material_group=r.material_group,
                    supply_status=r.status, created_by=user,
                )
                _sync_opening(contract, r.paid, user)
                if r.note:
                    Note.objects.create(contract=contract, kind=Note.Kind.IMPORT, text=r.note, created_by=user)
                contract.recalculate()
                _sync_closed(contract)
                result.created += 1
            else:
                if contract.supplier_id != supplier.id:
                    result.errors.append((
                        r.row_no,
                        f"{tjm.name} / {r.number} tizimda boshqa barterchiga ({contract.supplier.full_name}) tegishli",
                    ))
                    continue
                if contract.monthly_amount != r.monthly:
                    contract.monthly_amount = r.monthly
                    contract.debt_set_at = timezone.now()
                contract.material_type = r.material or contract.material_type
                contract.material_group = r.material_group
                contract.supply_status = r.status
                if contract.contract_date is None and r.contract_date:
                    contract.contract_date = _aware(r.contract_date)
                has_real_payments = contract.transactions.exclude(kind=Transaction.Kind.OPENING).exists()
                if not has_real_payments:
                    contract.total_amount = r.total
                    contract.save()
                    _sync_opening(contract, r.paid, user)
                    contract.recalculate()
                    _sync_closed(contract)
                else:
                    contract.save()
                    if contract.total_amount != r.total:
                        result.warnings.append((
                            r.row_no,
                            f"{r.number}: tizimda tushumlar kiritilgan — summalar Exceldan yangilanmadi",
                        ))
                if r.note and not contract.notes.filter(kind=Note.Kind.IMPORT, text=r.note).exists():
                    Note.objects.create(contract=contract, kind=Note.Kind.IMPORT, text=r.note, created_by=user)
                result.updated += 1
            if not contract.is_closed:
                result.debt_total += contract.remaining_amount
                result.arrears_total += contract.debt_amount

        if dry_run:
            transaction.set_rollback(True)

    if not dry_run:
        log_action(
            request, AuditLog.Action.IMPORT,
            f"Excel import: {result.created} yangi, {result.updated} yangilandi, {result.skipped} o'tkazildi, "
            f"{len(result.errors)} xato",
            user=user,
        )
    return result
