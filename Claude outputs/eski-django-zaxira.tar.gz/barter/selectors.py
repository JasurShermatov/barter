"""Dashboard, trend va oylik hisobot uchun hisob-kitoblar."""
from datetime import date
from decimal import Decimal

from django.db.models import Count, DecimalField, Q, Sum, Value
from django.db.models.functions import Coalesce, TruncMonth
from django.utils import timezone

from accounts.permissions import visible_contracts, visible_tjms

from .models import Note, Transaction
from .utils import MONTHS_UZ, add_months, aware, month_start, pct_change

DEC = DecimalField(max_digits=18, decimal_places=2)
ZERO = Value(Decimal("0"), output_field=DEC)


def _z(v):
    return v or Decimal("0")


def dashboard_kpis(user):
    agg = visible_contracts(user).aggregate(
        total=Sum("total_amount"),
        remaining=Sum("remaining_amount", filter=Q(is_closed=False)),
        debt=Sum("debt_amount", filter=Q(is_closed=False)),
        debtors=Count("id", filter=Q(is_closed=False, debt_amount__gt=0)),
        closed_count=Count("id", filter=Q(is_closed=True)),
        closed_sum=Sum("total_amount", filter=Q(is_closed=True)),
        active=Count("id", filter=Q(is_closed=False)),
        paid=Sum("paid_amount"),
    )
    result = {k: (_z(v) if k not in ("closed_count", "active") else v or 0) for k, v in agg.items()}
    result["count"] = result["active"] + result["closed_count"]
    result["paid_pct"] = int(result["paid"] * 100 / result["total"]) if result["total"] else 0
    result["debt_pct"] = int(result["debt"] * 100 / result["remaining"]) if result["remaining"] else 0
    return result


def tjm_summary(user):
    rows = (
        visible_tjms(user)
        .annotate(
            active_count=Count("contracts", filter=Q(contracts__is_closed=False)),
            remaining=Coalesce(Sum("contracts__remaining_amount", filter=Q(contracts__is_closed=False)), ZERO, output_field=DEC),
            debt=Coalesce(Sum("contracts__debt_amount", filter=Q(contracts__is_closed=False)), ZERO, output_field=DEC),
            debtors=Count("contracts", filter=Q(contracts__is_closed=False, contracts__debt_amount__gt=0)),
        )
        .order_by("-debt", "-remaining", "name")
    )
    rows = list(rows)
    top = max((r.debt for r in rows), default=0) or 1
    for r in rows:
        r.bar = int(r.debt * 100 / top)
    return rows


def top_debtors(user, limit=10):
    """Grafik bo'yicha eng katta qarzdorlar."""
    return (
        visible_contracts(user)
        .filter(is_closed=False, debt_amount__gt=0)
        .select_related("supplier", "tjm")
        .order_by("-debt_amount")[:limit]
    )


def recent_activity(user, limit=15):
    return (
        Transaction.objects.filter(contract__in=visible_contracts(user))
        .exclude(kind=Transaction.Kind.OPENING)
        .select_related("contract__supplier", "contract__tjm", "created_by")
        .order_by("-created_at")[:limit]
    )


def _key(value):
    if value is None:
        return None
    if hasattr(value, "tzinfo") and value.tzinfo is not None:
        value = timezone.localtime(value)
    return (value.year, value.month)


def monthly_trend(user, months=12):
    contracts = visible_contracts(user).order_by()
    today = timezone.localdate()
    start = add_months(month_start(today), -(months - 1))

    pays = (
        Transaction.objects.filter(contract__in=contracts, operation_date__gte=start)
        .exclude(kind=Transaction.Kind.OPENING)
        .annotate(m=TruncMonth("operation_date")).values("m")
        .annotate(s=Sum("amount"), c=Count("id")).order_by()
    )
    closed = (
        contracts.filter(closed_at__gte=aware(start))
        .annotate(m=TruncMonth("closed_at")).values("m")
        .annotate(s=Sum("total_amount"), c=Count("id")).order_by()
    )
    new = (
        contracts.filter(contract_date__gte=aware(start))
        .annotate(m=TruncMonth("contract_date")).values("m")
        .annotate(s=Sum("total_amount"), c=Count("id")).order_by()
    )
    calls = (
        Note.objects.filter(contract__in=contracts, kind__in=Note.CALL_KINDS, created_at__gte=aware(start))
        .annotate(m=TruncMonth("created_at")).values("m")
        .annotate(c=Count("id")).order_by()
    )
    pays_d = {_key(r["m"]): r for r in pays}
    closed_d = {_key(r["m"]): r for r in closed}
    new_d = {_key(r["m"]): r for r in new}
    calls_d = {_key(r["m"]): r["c"] for r in calls}

    result = []
    for i in range(months):
        d = add_months(start, i)
        k = (d.year, d.month)
        result.append({
            "key": f"{d.year}-{d.month:02d}",
            "short": f"{d.month:02d}/{str(d.year)[2:]}",
            "label": f"{MONTHS_UZ[d.month]} {d.year}",
            "pay_sum": _z(pays_d.get(k, {}).get("s")),
            "pay_count": pays_d.get(k, {}).get("c", 0),
            "closed_count": closed_d.get(k, {}).get("c", 0),
            "closed_sum": _z(closed_d.get(k, {}).get("s")),
            "new_count": new_d.get(k, {}).get("c", 0),
            "new_sum": _z(new_d.get(k, {}).get("s")),
            "calls": calls_d.get(k, 0),
        })
    return result


def _period_stats(contracts, start, end):
    pays = Transaction.objects.filter(
        contract__in=contracts, operation_date__gte=start, operation_date__lt=end
    ).exclude(kind=Transaction.Kind.OPENING)
    p = pays.aggregate(s=Sum("amount"), c=Count("id"))
    c = contracts.filter(closed_at__gte=aware(start), closed_at__lt=aware(end)).aggregate(
        s=Sum("total_amount"), c=Count("id")
    )
    n = contracts.filter(contract_date__gte=aware(start), contract_date__lt=aware(end)).aggregate(
        s=Sum("total_amount"), c=Count("id")
    )
    calls = Note.objects.filter(
        contract__in=contracts, kind__in=Note.CALL_KINDS,
        created_at__gte=aware(start), created_at__lt=aware(end),
    ).count()
    return {
        "pay_sum": _z(p["s"]), "pay_count": p["c"] or 0,
        "closed_sum": _z(c["s"]), "closed_count": c["c"] or 0,
        "new_sum": _z(n["s"]), "new_count": n["c"] or 0,
        "calls": calls,
    }


def monthly_report(user, year, month):
    contracts = visible_contracts(user).order_by()
    start = date(year, month, 1)
    end = add_months(start, 1)
    prev_start = add_months(start, -1)

    cur = _period_stats(contracts, start, end)
    prev = _period_stats(contracts, prev_start, start)
    changes = {k: pct_change(cur[k], prev[k]) for k in cur}

    state = contracts.aggregate(
        active=Count("id", filter=Q(is_closed=False)),
        remaining=Sum("remaining_amount", filter=Q(is_closed=False)),
        debt=Sum("debt_amount", filter=Q(is_closed=False)),
        debtors=Count("id", filter=Q(is_closed=False, debt_amount__gt=0)),
    )

    # TJM kesimi — alohida so'rovlar (JOIN ko'payib ketmasligi uchun)
    base = {
        r["tjm_id"]: r for r in contracts.values("tjm_id").annotate(
            active=Count("id", filter=Q(is_closed=False)),
            remaining=Sum("remaining_amount", filter=Q(is_closed=False)),
            debt=Sum("debt_amount", filter=Q(is_closed=False)),
            debtors=Count("id", filter=Q(is_closed=False, debt_amount__gt=0)),
        ).order_by()
    }
    pay_by = {
        r["contract__tjm_id"]: r for r in Transaction.objects.filter(
            contract__in=contracts, operation_date__gte=start, operation_date__lt=end
        ).exclude(kind=Transaction.Kind.OPENING)
        .values("contract__tjm_id").annotate(s=Sum("amount"), c=Count("id")).order_by()
    }
    closed_by = {
        r["tjm_id"]: r for r in contracts.filter(closed_at__gte=aware(start), closed_at__lt=aware(end))
        .values("tjm_id").annotate(s=Sum("total_amount"), c=Count("id")).order_by()
    }
    rows = []
    for tjm in visible_tjms(user):
        b = base.get(tjm.id, {})
        pay = pay_by.get(tjm.id, {})
        cl = closed_by.get(tjm.id, {})
        rows.append({
            "tjm": tjm,
            "active": b.get("active", 0),
            "remaining": _z(b.get("remaining")),
            "debt": _z(b.get("debt")),
            "debtors": b.get("debtors", 0),
            "pay_sum": _z(pay.get("s")),
            "pay_count": pay.get("c", 0),
            "closed_count": cl.get("c", 0),
            "closed_sum": _z(cl.get("s")),
        })
    rows.sort(key=lambda r: (-r["debt"], -r["remaining"], r["tjm"].name))
    totals = {
        "active": sum(r["active"] for r in rows),
        "remaining": sum((r["remaining"] for r in rows), Decimal("0")),
        "debt": sum((r["debt"] for r in rows), Decimal("0")),
        "debtors": sum(r["debtors"] for r in rows),
        "pay_sum": sum((r["pay_sum"] for r in rows), Decimal("0")),
        "pay_count": sum(r["pay_count"] for r in rows),
        "closed_count": sum(r["closed_count"] for r in rows),
        "closed_sum": sum((r["closed_sum"] for r in rows), Decimal("0")),
    }
    totals["debt_pct"] = int(totals["debt"] * 100 / totals["remaining"]) if totals["remaining"] else 0
    return {
        "year": year, "month": month, "label": f"{MONTHS_UZ[month]} {year}",
        "key": f"{year}-{month:02d}",
        "cur": cur, "prev": prev, "changes": changes,
        "active": state["active"] or 0, "remaining": _z(state["remaining"]), "debt": _z(state["debt"]),
        "debtors": state["debtors"] or 0,
        "rows": rows, "totals": totals,
    }
