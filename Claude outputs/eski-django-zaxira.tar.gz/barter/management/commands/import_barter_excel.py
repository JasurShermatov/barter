from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError

from barter.importer.runner import run_import
from barter.utils import fmt_short


class Command(BaseCommand):
    help = "Barter shartnomalarini Excel fayldan import qiladi (asl yoki tozalangan format)."

    def add_arguments(self, parser):
        parser.add_argument("path", help="xlsx fayl yo'li")
        parser.add_argument("--dry-run", action="store_true", help="Faqat tekshirish, bazaga yozmaslik")
        parser.add_argument("--user", help="Import qiluvchi login (audit uchun)")

    def handle(self, path, dry_run=False, user=None, **opts):
        u = None
        if user:
            u = get_user_model().objects.filter(username=user).first()
            if u is None:
                raise CommandError(f"Foydalanuvchi topilmadi: {user}")
        res = run_import(path, user=u, dry_run=dry_run)
        w = self.stdout.write
        w(f"Qatorlar: {res.total_rows}")
        w(self.style.SUCCESS(f"Yangi: {res.created}  |  Yangilandi: {res.updated}  |  O'tkazildi: {res.skipped}"))
        w(f"Yangi TJMlar: {len(res.tjms_created)}  |  Yangi barterchilar: {res.suppliers_created}")
        w(f"Avtomatik tuzatishlar: {res.fixes}  |  Aktiv qoldiq: {fmt_short(res.debt_total)}"
          f"  |  Qarzdorlik: {fmt_short(res.arrears_total)}")
        for row, msg in res.warnings:
            w(self.style.WARNING(f"  {row}-qator: {msg}"))
        for row, msg in res.errors:
            w(self.style.ERROR(f"  {row}-qator: {msg}"))
        if dry_run:
            w(self.style.NOTICE("Dry-run: bazaga hech narsa yozilmadi."))
