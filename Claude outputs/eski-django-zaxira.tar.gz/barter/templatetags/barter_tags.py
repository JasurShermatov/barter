from django import template
from django.utils import timezone

from barter.utils import fmt_short, fmt_som

register = template.Library()


@register.filter
def som(value):
    return fmt_som(value)


@register.filter
def short(value):
    return fmt_short(value)


@register.filter
def initial(name):
    name = (name or "").strip()
    return name[:1].upper() if name else "?"


@register.filter
def phone_fmt(p):
    """+998901234567 -> +998 90 123 45 67"""
    if p and p.startswith("+998") and len(p) == 13:
        return f"+998 {p[4:6]} {p[6:9]} {p[9:11]} {p[11:13]}"
    return p


@register.filter
def days_since(dt):
    if not dt:
        return None
    return (timezone.now() - dt).days


@register.filter
def signed_pct(value):
    if value is None:
        return ""
    return f"+{value}%" if value > 0 else f"{value}%"


@register.simple_tag(takes_context=True)
def qs(context, **kwargs):
    """Joriy GET parametrlarini saqlab, ba'zilarini almashtiradi: {% qs page=2 %}"""
    params = context["request"].GET.copy()
    for k, v in kwargs.items():
        if v in (None, ""):
            params.pop(k, None)
        else:
            params[k] = v
    encoded = params.urlencode()
    return f"?{encoded}" if encoded else "?"
