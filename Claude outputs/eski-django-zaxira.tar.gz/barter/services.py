"""Pul bilan bog'liq barcha o'zgarishlar faqat shu yerdan o'tadi (bitta haqiqat manbai)."""
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from audit.models import AuditLog
from audit.utils import log_action
from telegram_bot import notify

from .importer.cleaning import search_key
from .models import Contract, Note, Supplier, SupplierPhone, Transaction
from .utils import fmt_som


class ServiceError(Exception):
    pass


def _lock(contract):
    return Contract.objects.select_for_update().select_related("supplier", "tjm").get(pk=contract.pk)


def _close(contract, user, reason, note):
    contract.is_closed = True
    contract.closed_at = timezone.now()
    contract.closed_by = user
    contract.close_reason = reason
    contract.close_note = note
    contract.save(update_fields=["is_closed", "closed_at", "closed_by", "close_reason", "close_note", "updated_at"])
    contract.recalculate()


def _reopen(contract):
    contract.is_closed = False
    contract.closed_at = None
    contract.closed_by = None
    contract.close_reason = ""
    contract.close_note = ""
    contract.save(update_fields=["is_closed", "closed_at", "closed_by", "close_reason", "close_note", "updated_at"])
    contract.recalculate()


@transaction.atomic
def add_payment(*, contract, user, amount, kind, operation_date=None, note="", close_if_zero=True, request=None):
    contract = _lock(contract)
    amount = Decimal(amount)
    if contract.is_closed:
        raise ServiceError("Shartnoma yopilgan. Tushum kiritish uchun avval uni qayta oching.")
    if amount <= 0:
        raise ServiceError("Summa 0 dan katta bo'lishi kerak.")
    if amount > contract.remaining_amount:
        raise ServiceError(
            f"Summa qoldiq qarzdan ({fmt_som(contract.remaining_amount)} so'm) katta bo'lishi mumkin emas."
        )
    if kind == Transaction.Kind.OPENING:
        raise ServiceError("Bu turdagi yozuv faqat import orqali yaratiladi.")

    txn = Transaction.objects.create(
        contract=contract,
        amount=amount,
        kind=kind,
        operation_date=operation_date or timezone.localdate(),
        note=note.strip(),
        created_by=user,
    )
    contract.recalculate()
    closed = False
    if close_if_zero and contract.remaining_amount <= 0:
        _close(contract, user, Contract.CloseReason.FULFILLED, "Qoldiq 0 bo'ldi — avtomatik yopildi")
        closed = True

    log_action(
        request, AuditLog.Action.PAYMENT,
        f"{contract.supplier.full_name} | {contract.tjm.name} | {contract.number} | "
        f"{fmt_som(amount)} so'm | {txn.get_kind_display()}",
        obj=contract, user=user,
    )
    transaction.on_commit(lambda: notify.payment_created(txn.pk))
    if closed:
        log_action(request, AuditLog.Action.CLOSE, f"{contract.number}: qoldiq 0 — avtomatik", obj=contract, user=user)
        transaction.on_commit(lambda: notify.contract_closed(contract.pk))
    return txn, closed


@transaction.atomic
def delete_payment(*, txn, user, request=None):
    """Xato kiritilgan tushumni o'chiradi va qoldiqni avtomatik qaytaradi."""
    contract = _lock(txn.contract)
    amount, kind_label = txn.amount, txn.get_kind_display()
    txn.delete()
    contract.recalculate()
    reopened = False
    if contract.is_closed and contract.remaining_amount > 0 and contract.close_reason == Contract.CloseReason.FULFILLED:
        _reopen(contract)
        reopened = True
    log_action(
        request, AuditLog.Action.PAYMENT_DELETE,
        f"{contract.supplier.full_name} | {contract.number} | −{fmt_som(amount)} so'm ({kind_label}). "
        f"Yangi qoldiq: {fmt_som(contract.remaining_amount)}" + (" | shartnoma qayta ochildi" if reopened else ""),
        obj=contract, user=user,
    )
    return contract, reopened


def add_note(*, contract, user, kind, text, request=None):
    text = (text or "").strip()
    if kind == Note.Kind.NOTE and not text:
        raise ServiceError("Izoh matnini yozing.")
    note = Note.objects.create(contract=contract, kind=kind, text=text, created_by=user)
    log_action(
        request, AuditLog.Action.NOTE,
        f"{contract.number} | {note.get_kind_display()}" + (f": {text[:200]}" if text else ""),
        obj=contract, user=user,
    )
    return note


@transaction.atomic
def close_contract(*, contract, user, reason, note="", request=None):
    contract = _lock(contract)
    note = (note or "").strip()
    if contract.is_closed:
        raise ServiceError("Shartnoma allaqachon yopilgan.")
    if reason == Contract.CloseReason.FULFILLED and contract.remaining_amount > 0:
        raise ServiceError(
            f"Qoldiq qarz {fmt_som(contract.remaining_amount)} so'm. «Majburiyat bajarildi» faqat qoldiq 0 bo'lganda "
            "tanlanadi — aks holda boshqa sababni tanlang."
        )
    if reason != Contract.CloseReason.FULFILLED and not note:
        raise ServiceError("Bu sabab bilan yopishda izoh yozish majburiy.")
    _close(contract, user, reason, note)
    log_action(
        request, AuditLog.Action.CLOSE,
        f"{contract.supplier.full_name} | {contract.number} | {contract.get_close_reason_display()} | "
        f"yopilgan: {fmt_som(contract.paid_amount)}, qoldiq: {fmt_som(contract.remaining_amount)}"
        + (f" | {note}" if note else ""),
        obj=contract, user=user,
    )
    transaction.on_commit(lambda: notify.contract_closed(contract.pk))
    return contract


@transaction.atomic
def reopen_contract(*, contract, user, request=None):
    contract = _lock(contract)
    if not contract.is_closed:
        raise ServiceError("Shartnoma ochiq.")
    _reopen(contract)
    log_action(request, AuditLog.Action.REOPEN, f"{contract.supplier.full_name} | {contract.number}", obj=contract, user=user)
    return contract


def get_or_create_supplier(full_name, phones=()):
    key = search_key(full_name)
    supplier = Supplier.objects.filter(search_key=key).first()
    if supplier is None:
        supplier = Supplier.objects.create(full_name=full_name)
    for phone in phones:
        SupplierPhone.objects.get_or_create(supplier=supplier, phone=phone)
    return supplier


@transaction.atomic
def create_contract(*, data, user, request=None):
    supplier = get_or_create_supplier(data["supplier_name"], data.get("phones", []))
    contract = Contract.objects.create(
        supplier=supplier,
        tjm=data["tjm"],
        number=data["number"],
        contract_date=data.get("contract_date"),
        total_amount=data["total_amount"],
        monthly_amount=data.get("monthly_amount") or 0,
        debt_set_at=timezone.now(),
        material_type=data.get("material_type", ""),
        material_group=data.get("material_group") or Contract.MaterialGroup.BOSHQA,
        supply_status=data.get("supply_status", ""),
        created_by=user,
    )
    opening = data.get("opening_paid") or Decimal("0")
    if opening > 0:
        Transaction.objects.create(
            contract=contract, amount=opening, kind=Transaction.Kind.OPENING,
            note="Shartnoma kiritilganda berilgan chek", created_by=user,
        )
    if data.get("note"):
        Note.objects.create(contract=contract, kind=Note.Kind.NOTE, text=data["note"], created_by=user)
    contract.recalculate()
    log_action(
        request, AuditLog.Action.CONTRACT_CREATE,
        f"{supplier.full_name} | {contract.tjm.name} | {contract.number} | {fmt_som(contract.total_amount)} so'm",
        obj=contract, user=user,
    )
    transaction.on_commit(lambda: notify.contract_created(contract.pk))
    return contract


@transaction.atomic
def update_contract(*, contract, data, user, request=None):
    contract = _lock(contract)
    changes = []
    tracked = {
        "number": "raqam", "tjm": "TJM", "contract_date": "sana", "total_amount": "umumiy summa",
        "material_type": "hom ashyo", "material_group": "guruh", "supply_status": "holat",
    }
    for field, label in tracked.items():
        if field not in data:
            continue
        new = data[field]
        old = getattr(contract, field)
        if old != new:
            changes.append(f"{label}: {old} → {new}")
            setattr(contract, field, new)
    new_debt = data.get("monthly_amount")
    if new_debt is not None and abs(new_debt - contract.debt_amount) > Decimal("0.01"):
        changes.append(f"qarzdorlik: {fmt_som(contract.debt_amount)} → {fmt_som(new_debt)}")
        contract.monthly_amount = new_debt
        contract.debt_set_at = timezone.now()
    if data["total_amount"] < contract.paid_amount:
        raise ServiceError(
            f"Umumiy summa allaqachon yopilgan summadan ({fmt_som(contract.paid_amount)}) kam bo'lishi mumkin emas."
        )
    new_name = data["supplier_name"]
    if search_key(new_name) != contract.supplier.search_key or new_name != contract.supplier.full_name:
        changes.append(f"barterchi: {contract.supplier.full_name} → {new_name}")
        contract.supplier.full_name = new_name
        contract.supplier.save()
    old_phones = set(contract.supplier.phone_list)
    new_phones = set(data.get("phones", []))
    if old_phones != new_phones:
        contract.supplier.phones.exclude(phone__in=new_phones).delete()
        for p in new_phones - old_phones:
            SupplierPhone.objects.get_or_create(supplier=contract.supplier, phone=p)
        changes.append("telefonlar yangilandi")
    contract.save()
    contract.recalculate()
    if changes:
        log_action(request, AuditLog.Action.CONTRACT_EDIT, f"{contract.number}: " + "; ".join(changes), obj=contract, user=user)
    return contract
