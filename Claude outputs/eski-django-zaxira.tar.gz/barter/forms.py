from decimal import Decimal

from django import forms
from django.utils import timezone

from accounts.permissions import visible_tjms

from .importer.cleaning import clean_contract_number, clean_person_name, parse_material, parse_money, parse_phones
from .models import Contract, Note, Transaction


class MoneyField(forms.CharField):
    """'1 250 000' yoki '1250000,50' ko'rinishidagi summani qabul qiladi."""

    def __init__(self, *args, allow_zero=False, **kwargs):
        self.allow_zero = allow_zero
        kwargs.setdefault("widget", forms.TextInput(attrs={"inputmode": "decimal", "data-money": "1", "autocomplete": "off"}))
        super().__init__(*args, **kwargs)

    def prepare_value(self, value):
        if isinstance(value, Decimal):
            return f"{value:,.0f}".replace(",", " ")
        return value

    def clean(self, value):
        value = super().clean(value)
        if value in ("", None):
            return Decimal("0") if not self.required else None
        amount = parse_money(value)
        if amount is None:
            raise forms.ValidationError("Summani to'g'ri kiriting (masalan: 1 250 000).")
        if amount < 0 or (amount == 0 and not self.allow_zero):
            raise forms.ValidationError("Summa 0 dan katta bo'lishi kerak.")
        return amount


class PaymentForm(forms.Form):
    amount = MoneyField(label="Summa (so'm)")
    kind = forms.ChoiceField(
        label="Turi",
        choices=[c for c in Transaction.Kind.choices if c[0] != Transaction.Kind.OPENING],
        initial=Transaction.Kind.MATERIAL,
    )
    operation_date = forms.DateField(label="Sana", widget=forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"))
    note = forms.CharField(label="Izoh", required=False, max_length=255,
                           widget=forms.TextInput(attrs={"placeholder": "Masalan: 20 tonna sement, 16.09 yuk xati"}))
    close_if_zero = forms.BooleanField(label="Qoldiq 0 bo'lsa, shartnomani yopish", required=False, initial=True)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.is_bound:
            self.initial.setdefault("operation_date", timezone.localdate())

    def clean_operation_date(self):
        d = self.cleaned_data["operation_date"]
        if d > timezone.localdate():
            raise forms.ValidationError("Kelajak sanani kiritib bo'lmaydi.")
        return d


class NoteForm(forms.Form):
    kind = forms.ChoiceField(
        label="Turi", choices=[c for c in Note.Kind.choices if c[0] != Note.Kind.IMPORT], initial=Note.Kind.CALL
    )
    text = forms.CharField(label="Izoh", required=False, widget=forms.Textarea(attrs={"rows": 3, "placeholder": "Izoh yozing…"}))


class CloseForm(forms.Form):
    reason = forms.ChoiceField(label="Sabab", choices=Contract.CloseReason.choices)
    note = forms.CharField(label="Izoh", required=False, widget=forms.Textarea(attrs={"rows": 2}))


class ContractForm(forms.Form):
    supplier_name = forms.CharField(label="Barterchi F.I.SH", max_length=200)
    phones = forms.CharField(label="Telefon(lar)", required=False,
                             help_text="Bir nechta bo'lsa vergul bilan: +998901234567, +998911234567")
    tjm = forms.ModelChoiceField(label="TJM", queryset=None, empty_label="TJM tanlang")
    number = forms.CharField(label="Shartnoma raqami", max_length=50)
    contract_date = forms.DateTimeField(
        label="Shartnoma sanasi", required=False,
        widget=forms.DateTimeInput(attrs={"type": "datetime-local"}, format="%Y-%m-%dT%H:%M"),
        input_formats=["%Y-%m-%dT%H:%M", "%d.%m.%Y %H:%M", "%d.%m.%Y"],
    )
    total_amount = MoneyField(label="Umumiy summa (so'm)")
    opening_paid = MoneyField(label="Berilgan chek (boshlang'ich)", required=False, allow_zero=True)
    monthly_amount = MoneyField(
        label="Qarzdorlik summasi", required=False, allow_zero=True,
        help_text="Grafik bo'yicha hozir to'lanmagan summa. Keyingi tushumlar avval shuni yopadi.",
    )
    material_type = forms.CharField(label="Hom ashyo", max_length=60, required=False,
                                    widget=forms.TextInput(attrs={"list": "material-list"}))
    material_group = forms.ChoiceField(label="Guruh", choices=Contract.MaterialGroup.choices,
                                       initial=Contract.MaterialGroup.MATERIAL)
    supply_status = forms.ChoiceField(label="Yetkazib berish holati", choices=Contract.SupplyStatus.choices, required=False)
    note = forms.CharField(label="Izoh", required=False, widget=forms.Textarea(attrs={"rows": 2}))

    def __init__(self, *args, user=None, instance=None, **kwargs):
        self.instance = instance
        if instance is not None and "initial" not in kwargs:
            kwargs["initial"] = {
                "supplier_name": instance.supplier.full_name,
                "phones": ", ".join(instance.supplier.phone_list),
                "tjm": instance.tjm_id,
                "number": instance.number,
                "contract_date": timezone.localtime(instance.contract_date) if instance.contract_date else None,
                "total_amount": instance.total_amount,
                "monthly_amount": instance.debt_amount,
                "material_type": instance.material_type,
                "material_group": instance.material_group,
                "supply_status": instance.supply_status,
            }
        super().__init__(*args, **kwargs)
        self.fields["tjm"].queryset = visible_tjms(user)
        if instance is not None:
            del self.fields["opening_paid"]
            del self.fields["note"]

    def clean_supplier_name(self):
        return clean_person_name(self.cleaned_data["supplier_name"])

    def clean_number(self):
        return clean_contract_number(self.cleaned_data["number"])

    def clean_material_type(self):
        return parse_material(self.cleaned_data.get("material_type", ""))

    def clean_phones(self):
        phones, problem = parse_phones(self.cleaned_data.get("phones", ""))
        if problem:
            raise forms.ValidationError(problem)
        return phones

    def clean(self):
        data = super().clean()
        tjm, number = data.get("tjm"), data.get("number")
        if tjm and number:
            qs = Contract.objects.filter(tjm=tjm, number=number)
            if self.instance is not None:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                self.add_error("number", f"{tjm.name} da {number} raqamli shartnoma allaqachon bor.")
        total, opening = data.get("total_amount"), data.get("opening_paid")
        if total is not None and opening and opening > total:
            self.add_error("opening_paid", "Berilgan chek umumiy summadan katta bo'lishi mumkin emas.")
        debt = data.get("monthly_amount") or 0
        if total is not None and debt:
            paid = self.instance.paid_amount if self.instance is not None else (opening or 0)
            if debt > total - paid:
                self.add_error("monthly_amount", "Qarzdorlik qoldiq summadan katta bo'lishi mumkin emas.")
        return data


class ImportForm(forms.Form):
    file = forms.FileField(label="Excel fayl (.xlsx)")
    dry_run = forms.BooleanField(label="Faqat tekshirish (bazaga yozmaslik)", required=False, initial=True)

    def clean_file(self):
        f = self.cleaned_data["file"]
        if not f.name.lower().endswith((".xlsx", ".xlsm")):
            raise forms.ValidationError("Faqat .xlsx formatidagi fayl qabul qilinadi.")
        return f
