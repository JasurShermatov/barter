from datetime import date, timedelta

from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Count, Q, Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST

from accounts.permissions import admin_required, visible_contracts, visible_tjms
from audit.models import AuditLog
from audit.utils import log_action

from . import exports, selectors, services
from .forms import CloseForm, ContractForm, ImportForm, NoteForm, PaymentForm
from .importer.cleaning import search_key
from .importer.runner import run_import
from .models import Contract, Transaction

PAGE_SIZE = 50


def permission_denied(request, exception=None):
    return render(request, "403.html", {"message": str(exception or "")}, status=403)


def _get_contract(request, pk):
    return get_object_or_404(visible_contracts(request.user).select_related("supplier", "tjm"), pk=pk)


def _is_htmx(request):
    return request.headers.get("HX-Request") == "true"


# ================================================================ DASHBOARD
@login_required
def dashboard(request):
    ctx = {
        "kpi": selectors.dashboard_kpis(request.user),
        "tjm_rows": selectors.tjm_summary(request.user),
        "top": selectors.top_debtors(request.user, 10),
        "activity": selectors.recent_activity(request.user, 12),
    }
    return render(request, "dashboard.html", ctx)


# ================================================================ BARTERLAR
def _filtered_contracts(request):
    qs = visible_contracts(request.user).select_related("supplier", "tjm").prefetch_related("supplier__phones")
    g = request.GET
    q = g.get("q", "").strip()
    if q:
        digits = "".join(ch for ch in q if ch.isdigit())
        cond = Q(supplier__search_key__icontains=search_key(q)) | Q(number__icontains=q.upper())
        if len(digits) >= 4:
            cond |= Q(supplier__phones__phone__contains=digits)
        qs = qs.filter(cond).distinct()
    if g.get("tjm"):
        qs = qs.filter(tjm_id=g["tjm"])
    holat = g.get("holat", "")
    if holat == "none":
        qs = qs.filter(supply_status="")
    elif holat:
        qs = qs.filter(supply_status=holat)
    if g.get("guruh"):
        qs = qs.filter(material_group=g["guruh"])
    if g.get("material"):
        qs = qs.filter(material_type=g["material"])
    qarz = g.get("qarz", "")
    if qarz == "bor":
        qs = qs.filter(debt_amount__gt=0)
    elif qarz == "yoq":
        qs = qs.filter(debt_amount__lte=0)
    if g.get("tushum") == "30":
        qs = qs.filter(Q(last_payment_at__lt=timezone.now() - timedelta(days=30)) | Q(last_payment_at__isnull=True))
    elif g.get("tushum") == "hech":
        qs = qs.filter(last_payment_at__isnull=True)
    closed_mode = g.get("yopilgan", "")
    if closed_mode == "faqat":
        qs = qs.filter(is_closed=True)
    elif closed_mode != "1":
        qs = qs.filter(is_closed=False)
    order = g.get("sort", "-remaining_amount")
    allowed = {
        "-remaining_amount", "remaining_amount", "-total_amount", "-contract_date", "contract_date",
        "supplier__full_name", "-last_payment_at", "last_payment_at", "-debt_amount",
    }
    if order not in allowed:
        order = "-remaining_amount"
    return qs.order_by(order, "pk")


@login_required
def contract_list(request):
    qs = _filtered_contracts(request)
    totals = qs.order_by().aggregate(
        remaining=Sum("remaining_amount", filter=Q(is_closed=False)),
        debt=Sum("debt_amount", filter=Q(is_closed=False)),
        debtors=Count("id", filter=Q(is_closed=False, debt_amount__gt=0)),
        total=Sum("total_amount"),
    )
    page = Paginator(qs, PAGE_SIZE).get_page(request.GET.get("page"))
    materials = (
        visible_contracts(request.user).exclude(material_type="")
        .values_list("material_type", flat=True).distinct().order_by("material_type")
    )
    ctx = {
        "page": page,
        "count": page.paginator.count,
        "totals": totals,
        "tjms": visible_tjms(request.user),
        "statuses": Contract.SupplyStatus.choices,
        "groups": Contract.MaterialGroup.choices,
        "materials": list(materials),
        "f": request.GET,
        "open_id": request.GET.get("open", "") if request.GET.get("open", "").isdigit() else "",
    }
    return render(request, "barter/list.html", ctx)


@login_required
def contract_export(request):
    qs = _filtered_contracts(request)
    log_action(request, AuditLog.Action.EXPORT, f"Barterlar ro'yxati: {qs.count()} ta")
    return exports.export_contracts(qs)


def _detail_context(request, contract, **extra):
    transactions = contract.transactions.select_related("created_by").all()
    notes = contract.notes.select_related("created_by").all()
    history = sorted(
        [("t", t.created_at, t) for t in transactions] + [("n", n.created_at, n) for n in notes],
        key=lambda x: x[1], reverse=True,
    )
    real = [t for t in transactions if not t.is_opening]
    ctx = {
        "c": contract,
        "phones": contract.supplier.phone_list,
        "history": history,
        "transactions": transactions,
        "real_sum": sum((t.amount for t in real), 0),
        "other_contracts": contract.supplier.contracts.exclude(pk=contract.pk).select_related("tjm")
        if request.user.is_admin
        else visible_contracts(request.user, contract.supplier.contracts.exclude(pk=contract.pk)).select_related("tjm"),
        "payment_form": PaymentForm(),
        "note_form": NoteForm(),
        "close_form": CloseForm(initial={
            "reason": Contract.CloseReason.FULFILLED if contract.remaining_amount <= 0 else Contract.CloseReason.UNIT_RETURNED
        }),
        "tab": "izoh",
    }
    ctx.update(extra)
    return ctx


def _render_detail(request, contract, changed=False, **extra):
    contract.refresh_from_db()
    resp = render(request, "barter/_detail.html", _detail_context(request, contract, **extra))
    if changed:
        resp["HX-Trigger"] = "contractChanged"
    return resp


@login_required
def contract_detail(request, pk):
    contract = _get_contract(request, pk)
    if not _is_htmx(request):
        return redirect(f"{reverse('barter:list')}?open={contract.pk}&yopilgan=1")
    return _render_detail(request, contract)


@login_required
@require_POST
def contract_payment(request, pk):
    contract = _get_contract(request, pk)
    form = PaymentForm(request.POST)
    if not form.is_valid():
        return _render_detail(request, contract, payment_form=form, tab="tolov")
    try:
        txn, closed = services.add_payment(
            contract=contract, user=request.user, request=request,
            amount=form.cleaned_data["amount"], kind=form.cleaned_data["kind"],
            operation_date=form.cleaned_data["operation_date"], note=form.cleaned_data["note"],
            close_if_zero=form.cleaned_data["close_if_zero"],
        )
    except services.ServiceError as exc:
        form.add_error("amount", str(exc))
        return _render_detail(request, contract, payment_form=form, tab="tolov")
    flash = f"Tushum saqlandi: {txn.amount:,.0f} so'm.".replace(",", " ")
    if closed:
        flash += " Qoldiq 0 bo'ldi — shartnoma yopildi."
    return _render_detail(request, contract, changed=True, flash=flash, tab="tolov")


@login_required
@require_POST
def contract_note(request, pk):
    contract = _get_contract(request, pk)
    form = NoteForm(request.POST)
    if not form.is_valid():
        return _render_detail(request, contract, note_form=form)
    try:
        services.add_note(contract=contract, user=request.user, request=request, **form.cleaned_data)
    except services.ServiceError as exc:
        form.add_error("text", str(exc))
        return _render_detail(request, contract, note_form=form)
    return _render_detail(request, contract, changed=True, flash="Izoh saqlandi.")


@login_required
@require_POST
def contract_close(request, pk):
    contract = _get_contract(request, pk)
    form = CloseForm(request.POST)
    if not form.is_valid():
        return _render_detail(request, contract, close_form=form, tab="yopish")
    try:
        services.close_contract(contract=contract, user=request.user, request=request, **form.cleaned_data)
    except services.ServiceError as exc:
        form.add_error(None, str(exc))
        return _render_detail(request, contract, close_form=form, tab="yopish")
    return _render_detail(request, contract, changed=True, flash="Shartnoma yopildi va arxivga o'tkazildi.", tab="yopish")


@admin_required
@require_POST
def contract_reopen(request, pk):
    contract = _get_contract(request, pk)
    try:
        services.reopen_contract(contract=contract, user=request.user, request=request)
    except services.ServiceError as exc:
        return _render_detail(request, contract, flash_error=str(exc), tab="yopish")
    return _render_detail(request, contract, changed=True, flash="Shartnoma qayta ochildi.", tab="tolov")


@admin_required
@require_POST
def payment_delete(request, pk):
    txn = get_object_or_404(
        Transaction.objects.filter(contract__in=visible_contracts(request.user)).select_related("contract"), pk=pk
    )
    contract, reopened = services.delete_payment(txn=txn, user=request.user, request=request)
    msg = "Tushum o'chirildi, qoldiq qarz qayta tiklandi."
    if reopened:
        msg += " Shartnoma qayta ochildi."
    if _is_htmx(request):
        return _render_detail(request, contract, changed=True, flash=msg, tab="tolov")
    messages.success(request, msg)
    nxt = request.POST.get("next", "")
    if nxt and url_has_allowed_host_and_scheme(nxt, allowed_hosts={request.get_host()}):
        return redirect(nxt)
    return redirect("barter:payments")


@login_required
def contract_create(request):
    form = ContractForm(request.POST or None, user=request.user)
    if request.method == "POST" and form.is_valid():
        contract = services.create_contract(data=form.cleaned_data, user=request.user, request=request)
        messages.success(request, f"{contract.number} shartnomasi qo'shildi.")
        return redirect(f"{reverse('barter:list')}?open={contract.pk}&yopilgan=1")
    return render(request, "barter/contract_form.html", {"form": form, "materials": _materials(request)})


@login_required
def contract_edit(request, pk):
    contract = _get_contract(request, pk)
    form = ContractForm(request.POST or None, user=request.user, instance=contract)
    if request.method == "POST" and form.is_valid():
        try:
            services.update_contract(contract=contract, data=form.cleaned_data, user=request.user, request=request)
        except services.ServiceError as exc:
            form.add_error("total_amount", str(exc))
        else:
            messages.success(request, "O'zgarishlar saqlandi.")
            return redirect(f"{reverse('barter:list')}?open={contract.pk}&yopilgan=1")
    return render(request, "barter/contract_form.html", {"form": form, "contract": contract, "materials": _materials(request)})


def _materials(request):
    return list(
        visible_contracts(request.user).exclude(material_type="")
        .values_list("material_type", flat=True).distinct().order_by("material_type")
    )


@admin_required
def contract_import(request):
    form = ImportForm(request.POST or None, request.FILES or None)
    result = None
    if request.method == "POST" and form.is_valid():
        result = run_import(
            form.cleaned_data["file"], user=request.user, dry_run=form.cleaned_data["dry_run"], request=request
        )
        if not result.dry_run and result.ok:
            messages.success(request, f"Import tugadi: {result.created} yangi, {result.updated} yangilandi.")
    return render(request, "barter/import.html", {"form": form, "result": result})


# ================================================================ TO'LOVLAR
def _filtered_payments(request):
    qs = (
        Transaction.objects.filter(contract__in=visible_contracts(request.user))
        .exclude(kind=Transaction.Kind.OPENING)
        .select_related("contract__supplier", "contract__tjm", "created_by")
    )
    g = request.GET
    month = g.get("oy", "")
    if month:
        try:
            y, m = (int(x) for x in month.split("-"))
            start = date(y, m, 1)
            end = date(y + (m == 12), m % 12 + 1, 1)
            qs = qs.filter(operation_date__gte=start, operation_date__lt=end)
        except ValueError:
            pass
    if g.get("sana"):
        qs = qs.filter(operation_date=g["sana"])
    q = g.get("q", "").strip()
    if q:
        qs = qs.filter(
            Q(contract__supplier__search_key__icontains=search_key(q)) | Q(contract__number__icontains=q.upper())
        )
    if g.get("tjm"):
        qs = qs.filter(contract__tjm_id=g["tjm"])
    if g.get("turi"):
        qs = qs.filter(kind=g["turi"])
    if g.get("operator"):
        qs = qs.filter(created_by_id=g["operator"])
    return qs.order_by("-created_at")


@login_required
def payment_list(request):
    qs = _filtered_payments(request)
    agg = qs.aggregate(s=Sum("amount"), c=Count("id"))
    page = Paginator(qs, PAGE_SIZE).get_page(request.GET.get("page"))
    months = selectors.monthly_trend(request.user, 12)[::-1]
    operators = get_user_model().objects.filter(
        transactions__contract__in=visible_contracts(request.user)
    ).distinct().order_by("full_name")
    ctx = {
        "page": page,
        "agg": agg,
        "months": months,
        "tjms": visible_tjms(request.user),
        "kinds": [c for c in Transaction.Kind.choices if c[0] != Transaction.Kind.OPENING],
        "operators": operators,
        "f": request.GET,
    }
    return render(request, "payments/list.html", ctx)


@login_required
def payment_export(request):
    qs = _filtered_payments(request)
    log_action(request, AuditLog.Action.EXPORT, f"Tushumlar: {qs.count()} ta")
    return exports.export_payments(qs)


# ================================================================ TAHLIL
@login_required
def trend(request):
    try:
        months = int(request.GET.get("oylar", 12))
    except ValueError:
        months = 12
    months = months if months in (3, 6, 12, 24) else 12
    rows = selectors.monthly_trend(request.user, months)
    totals = {
        "pay_sum": sum(r["pay_sum"] for r in rows),
        "pay_count": sum(r["pay_count"] for r in rows),
        "closed_count": sum(r["closed_count"] for r in rows),
        "new_count": sum(r["new_count"] for r in rows),
        "new_sum": sum(r["new_sum"] for r in rows),
        "calls": sum(r["calls"] for r in rows),
    }
    chart = {
        "labels": [r["short"] for r in rows],
        "pay": [float(r["pay_sum"]) for r in rows],
        "closed": [r["closed_count"] for r in rows],
        "new": [r["new_count"] for r in rows],
    }
    by_group = (
        Transaction.objects.filter(contract__in=visible_contracts(request.user))
        .exclude(kind=Transaction.Kind.OPENING)
        .filter(operation_date__gte=date.fromisoformat(rows[0]["key"] + "-01"))
        .values("contract__material_group").annotate(s=Sum("amount")).order_by("-s")
    )
    group_labels = dict(Contract.MaterialGroup.choices)
    groups = [{"label": group_labels.get(g["contract__material_group"], "—"), "sum": g["s"]} for g in by_group]
    return render(request, "reports/trend.html", {
        "rows": rows[::-1], "totals": totals, "chart": chart, "months": months, "groups": groups,
    })


def _report_month(request):
    today = timezone.localdate()
    try:
        y, m = (int(x) for x in request.GET.get("oy", "").split("-"))
        date(y, m, 1)
    except (ValueError, TypeError):
        y, m = today.year, today.month
    return y, m


@login_required
def monthly(request):
    y, m = _report_month(request)
    report = selectors.monthly_report(request.user, y, m)
    return render(request, "reports/monthly.html", {"r": report})


@login_required
def monthly_export(request):
    y, m = _report_month(request)
    report = selectors.monthly_report(request.user, y, m)
    log_action(request, AuditLog.Action.EXPORT, f"Oylik hisobot {report['key']}")
    return exports.export_monthly(report)
