from django.urls import path

from . import views

app_name = "barter"
urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("barterlar/", views.contract_list, name="list"),
    path("barterlar/export/", views.contract_export, name="export"),
    path("barterlar/import/", views.contract_import, name="import"),
    path("barterlar/yangi/", views.contract_create, name="create"),
    path("barterlar/<int:pk>/", views.contract_detail, name="detail"),
    path("barterlar/<int:pk>/tahrir/", views.contract_edit, name="edit"),
    path("barterlar/<int:pk>/tushum/", views.contract_payment, name="payment"),
    path("barterlar/<int:pk>/izoh/", views.contract_note, name="note"),
    path("barterlar/<int:pk>/yopish/", views.contract_close, name="close"),
    path("barterlar/<int:pk>/qayta-ochish/", views.contract_reopen, name="reopen"),
    path("tolovlar/", views.payment_list, name="payments"),
    path("tolovlar/export/", views.payment_export, name="payments_export"),
    path("tolovlar/<int:pk>/ochirish/", views.payment_delete, name="payment_delete"),
    path("trend/", views.trend, name="trend"),
    path("oylik-hisobot/", views.monthly, name="monthly"),
    path("oylik-hisobot/excel/", views.monthly_export, name="monthly_export"),
]
